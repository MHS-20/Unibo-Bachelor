package favoliere.model;

public interface ConIndice {
	int getIndice();  
}
