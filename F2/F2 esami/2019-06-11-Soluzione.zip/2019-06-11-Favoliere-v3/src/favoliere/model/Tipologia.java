package favoliere.model;

public enum Tipologia {
	NEGATIVO, POSITIVO; 
}
