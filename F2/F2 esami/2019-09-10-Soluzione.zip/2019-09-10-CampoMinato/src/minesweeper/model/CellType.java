package minesweeper.model;

public enum CellType {
	MINE, NUM, HIDDEN;
}
