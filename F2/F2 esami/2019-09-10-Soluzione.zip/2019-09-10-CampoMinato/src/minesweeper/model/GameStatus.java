package minesweeper.model;

public enum GameStatus {
	CONTINUING, EXPLODED, WON;
}
