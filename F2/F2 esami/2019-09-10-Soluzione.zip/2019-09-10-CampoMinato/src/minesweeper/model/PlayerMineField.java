package minesweeper.model;

public class PlayerMineField extends MineField {

	private int hiddenCells;
	
	public PlayerMineField(int size) {
		super(size);
		init();
	}

	@Override
	protected void init() {
		// grid must start empty
		hiddenCells = this.getSize()*this.getSize();
		for (int row=0; row<this.getSize(); row++)
			for (int col=0; col<this.getSize(); col++)
				super.setCell(row,col, new Cell(CellType.HIDDEN));
	}

	@Override
	protected void setCell(int row, int col, Cell cell) {
		super.setCell(row, col, cell);
		if(cell.getType()==CellType.HIDDEN) throw new UnsupportedOperationException("cannot override a hidden cell with another one)");
		hiddenCells--;
	}
	
	public int getHiddenCellsNumber() {
		return this.hiddenCells;
	}
}

