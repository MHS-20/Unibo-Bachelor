package minesweeper.persistence;

public interface ConfigReader {
	int getSize();
	int getMinesNumber();
}
