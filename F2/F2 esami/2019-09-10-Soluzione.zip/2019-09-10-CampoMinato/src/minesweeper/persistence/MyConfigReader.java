package minesweeper.persistence;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.Reader;

public class MyConfigReader implements ConfigReader {
	
	private int size=0, mines=0;
	
	public MyConfigReader(Reader reader) throws BadFileFormatException {
		BufferedReader rdr = new BufferedReader(reader);
		String line;
		try {
			while((line=rdr.readLine())!=null) {
				String[] items = line.split(":");
				switch(items[0].trim().toLowerCase()) {
					case "mines": 
						mines=Integer.parseInt(items[1].trim());
						break;
					case "size": 
						size=Integer.parseInt(items[1].trim());
						break;
					default:
						throw new BadFileFormatException("Bad keyword - " + items[0]);
				}
			}
		} catch (NumberFormatException e) {
			throw new BadFileFormatException("Int expected - " + e);
		} catch (IOException e) {
			throw new BadFileFormatException("I/O error - " + e);
		}
	}

	@Override
	public int getSize() {
		return size;
	}

	@Override
	public int getMinesNumber() {
		return mines;
	}	
	
}
