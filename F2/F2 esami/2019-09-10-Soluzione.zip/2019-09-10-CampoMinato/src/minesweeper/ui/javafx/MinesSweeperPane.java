package minesweeper.ui.javafx;

import javafx.event.ActionEvent;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;
import minesweeper.ui.controller.Controller;

public class MinesSweeperPane extends BorderPane {

	private TextArea output;
	private Button save, restart;
	private Controller controller;
	private MinesSweeperGrid grid;
	
	public MinesSweeperPane(Controller controller, Stage stage) {
		this.controller=controller;
		HBox topPane = new HBox();
		topPane.getChildren().addAll(new Label("Mines: "+controller.getMinesNumber()));
		this.setTop(topPane);
		//
		output = new TextArea();
		output.setPrefColumnCount(60);
		output.setPrefRowCount(10);
		output.setFont(Font.font("Courier New", FontWeight.NORMAL, 12));
		//
		this.setRight(output);
		//
		HBox bottomPane = new HBox();
		save = new Button("Save status");
		bottomPane.getChildren().add(save);
		save.setOnAction(this::saver);
		//
		restart = new Button("Restart");
		bottomPane.getChildren().add(restart);
		restart.setOnAction(this::restarter);
		//
		this.setBottom(bottomPane);
		grid = new MinesSweeperGrid(controller, output);
		this.setCenter(grid);
	}
	
	private void saver(ActionEvent e) {
		controller.save();
	}

	private void restarter(ActionEvent e) {
		controller.restart();
		output.setText("");
		grid = new MinesSweeperGrid(controller, output);
		this.setCenter(grid);
	}

}
