package minirail.model;

import java.text.NumberFormat;
import java.util.Map;
import java.util.Set;

public class MyRunner implements Runner	{
	
	private Map<String, LineStatus> lines;
	private Gauge gauge;
	private StringBuilder logger;
	
	public MyRunner(Map<String, LineStatus> lines, Gauge gauge) {
		if (lines==null) throw new IllegalArgumentException("Null lines for runner");
		this.lines = lines;
		this.gauge=gauge;
		this.logger=new StringBuilder();
	}
	
	@Override
	public Map<String, LineStatus> getLines() {
		return this.lines;
	}

	@Override
	public Gauge getGauge() {
		return gauge;
	}
	
	@Override
	public void clock(double period) {
		for(String lineID : lines.keySet()) {
			LineStatus lineStatus = lines.get(lineID);
			Set<Train> trainSet = lineStatus.getAllTrains();
			for (Train t : trainSet) { 
				moveTrain(lineStatus, t, period);
			}
		}		
	}

	private void moveTrain(LineStatus lineStatus, Train t, double period) {
		// recupera posizione treno, addiziona spazio percorso in 1 secondo, poi ricolloca treno nella nuova posizione
		double pos = lineStatus.getTrainLocation(t);
		double space = period*gauge.kmhToCms(t.getSpeed());
		double newpos = (pos+space) % lineStatus.getLine().getLength(); 
		boolean result = lineStatus.moveTrain(t, newpos);
		NumberFormat formatter = NumberFormat.getInstance();
		formatter.setMaximumFractionDigits(2); formatter.setMinimumFractionDigits(2);
		logger.append("Trying to move " + t.getName() + " running at " + formatter.format(t.getSpeed()) + " km/h " + 
					  "from pos " + formatter.format(pos) + " to pos " + formatter.format(newpos) + ": " + 
					  (result ? "success" : "failure") + System.lineSeparator());
	}

	@Override
	public String toString() {
		return logger.toString();
	}
	
}

