package minirail.persistence;

import minirail.model.Line;

public interface LineReader {
	Line getLine();
}
