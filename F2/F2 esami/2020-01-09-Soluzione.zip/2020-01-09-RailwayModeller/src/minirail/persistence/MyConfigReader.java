package minirail.persistence;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;
import java.util.List;

import minirail.model.Gauge;
import minirail.model.Train;

public class MyConfigReader implements ConfigReader {
	
	// N gauge
	// IC583, 65 cm, 160 km/h
	// R2961, 68 cm, 140 km/h
	
	private List<Train> trains;
	private String stringGauge;
	private Gauge gauge;
	
	public MyConfigReader(Reader reader) throws BadFileFormatException, IOException {
		trains = new ArrayList<>();
		BufferedReader rdr = new BufferedReader(reader);
		String line;
		try {
			line=rdr.readLine(); 
			if (line==null) throw new BadFileFormatException("No gauge specification in file header");
			String[] subItems0 = line.split(" ");
			stringGauge=subItems0[0].trim().toUpperCase();
			if (!stringGauge.equals("N") && !stringGauge.equals("H0") && !stringGauge.equals("Z") && !stringGauge.equals("TT")) throw new BadFileFormatException("Gauge must be one of 'N', 'H0', 'TT', or 'Z' - " + stringGauge);
			else gauge = Gauge.valueOf(stringGauge);
			//
			if (subItems0[1]==null || !subItems0[1].equals("gauge")) throw new BadFileFormatException("Missing keyword 'gauge' in header line ' - " + subItems0[1]);
			// now reading trains
			while((line=rdr.readLine())!=null) {
				String[] items = line.split(",");
				if (items.length!=3) throw new BadFileFormatException("Some comma is missing in line - " + line);
				// items[0] is the train name -> no change
				// items[1] is the model length and unit -> extract number, check unit (cm or in) and convert as appropriate
				// items[2] is the real train speed and unit -> extract number, check unit (km/h or mph) and convert as appropriate
				if (items[0]==null || items[0].isEmpty()) throw new BadFileFormatException("Train name must not be void - " + items[0]);
				if (items[1]==null || items[1].isEmpty()) throw new BadFileFormatException("Model length must not be void - " + items[1]);
				if (items[2]==null || items[2].isEmpty()) throw new BadFileFormatException("Real train speed must not be void - " + items[2]);
				//
				String[] subItems1 = items[1].trim().split(" ");
				double length = Double.parseDouble(subItems1[0]);
				if (!subItems1[1].trim().equals("cm") && !subItems1[1].trim().equals("in")) throw new BadFileFormatException("Model length be in either 'cm' or 'in' - " + subItems1[1]);
				//
				String[] subItems2 = items[2].trim().split(" ");
				int speed = Integer.parseInt(subItems2[0]);
				if (!subItems2[1].trim().equals("km/h") && !subItems2[1].trim().equals("mph")) throw new BadFileFormatException("Train speed be in either 'km/h' or 'mph' - " + subItems2[1]);
				// 
				trains.add(new Train(items[0], length, speed));
			}
		} catch (NumberFormatException e) {
			throw new BadFileFormatException("Number expected - " + e);
		}
	}

	@Override
	public List<Train> getTrains() {
		return trains;
	}

	@Override
	public Gauge getGauge() {
		return gauge;
	}
	
}
