package minirail.persistence;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;
import java.util.List;

import minirail.model.Line;
import minirail.model.Section;

public class MyLineReader implements LineReader {
	
	// Line xxxxxx
	// Section aaa 90
	// Section bbb 90
	// Section ccc 70
	// Section ddd 70
	
	private List<Section> sections;
	private String lineName, lineKeyword;
	private Line line;
	
	public MyLineReader(Reader reader) throws BadFileFormatException, IOException {
		sections = new ArrayList<>();
		BufferedReader rdr = new BufferedReader(reader);
		String s;
		try {
			s=rdr.readLine(); 
			if (s==null) throw new BadFileFormatException("No line name specification in file header");
			String[] subItems0 = s.split(" ");
			if (subItems0.length!=2) throw new BadFileFormatException("Wrong header format - expected 'Line' + line name");
			lineKeyword=subItems0[0].trim().toUpperCase();
			if (!lineKeyword.equals("LINE")) throw new BadFileFormatException("Missing 'Line' keyword in header - " + lineKeyword);
			lineName=subItems0[1].trim();
			//
			while((s=rdr.readLine())!=null) {
				String[] items = s.split(" ");
				if (items.length!=3) throw new BadFileFormatException("Wrong format in section - " + s);
				// items[0] is the word 'Section' -> no change
				// items[1] is the section name 
				// items[2] is the section length 
				if (items[0]==null || !items[0].trim().equalsIgnoreCase("Section")) throw new BadFileFormatException("Missing 'Section' keyword - " + items[0]);
				if (items[1]==null || items[1].isEmpty() || items[1].isEmpty()) throw new BadFileFormatException("Section name must not be void - " + items[1]);
				double len = Double.parseDouble(items[2].trim());
				//
				sections.add(new Section(items[1], len));
			}
		} catch (NumberFormatException e) {
			throw new BadFileFormatException("Number expected - " + e);
		}
		line = new Line(lineName, sections);
	}

	@Override
	public Line getLine() {
		return line;
	}
	
}
