package minirail.ui.javafx;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import javafx.event.ActionEvent;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import minirail.model.Train;
import minirail.model.TrainStatus;
import minirail.ui.controller.Controller;

public class MiniRailPane extends BorderPane {

	private TextArea output;
	private Button clock, moving, stopping;
	private Controller controller;
	private Label label;
	private Map<Train,Color> trainColors;
	
	public MiniRailPane(Controller controller, double[] trainPositions) {
		this.controller=controller;
		//
		trainColors = new HashMap<>();
		drawTrainColors(trainColors);
		//
		HBox topPane = new HBox(5);
		moving = new Button("Move trains");
		stopping = new Button("Stop trains");
		label = new Label("Trains are now " + TrainStatus.STOPPED);
		topPane.getChildren().addAll(moving, stopping, label);
		moving.setOnAction(this::moveTrains);
		stopping.setOnAction(this::stopTrains);
		this.setTop(topPane);
		//
		output = new TextArea();
		output.setWrapText(true);
		output.setPrefColumnCount(10);
		output.setPrefRowCount(20);
		output.setFont(Font.font("Courier New", FontWeight.NORMAL, 12));
		//
		this.setBottom(output);
		//
		HBox rightPane = new HBox();
		clock = new Button("Clock");
		rightPane.getChildren().add(clock);
		clock.setOnAction(this::advanceClock);
		//
		this.setRight(rightPane);
		//		
		setupTrainPanel(trainPositions);
	}
	
	private void drawTrainColors(Map<Train, Color> trainColors) {
		for (Train t: this.controller.getTrains()) {
			trainColors.put(t,randomColor());
		}
	}

	private void advanceClock(ActionEvent e) {
		controller.clock(0.5);
		output.setText(controller.getLog());
		updateTrainPanel();
	}

	private void moveTrains(ActionEvent e) {
		for (Train t: this.controller.getTrains())
			this.controller.setMoving(t);
		label.setText("Trains are now " + TrainStatus.MOVING);
	}

	private void stopTrains(ActionEvent e) {
		for (Train t: this.controller.getTrains())
			this.controller.setStopped(t);
		label.setText("Trains are now " + TrainStatus.STOPPED);
	}
	
	private void setupTrainPanel(double[] trainPositions) {
		TrainLinePane centerPane = new TrainLinePane(this.controller.getLine());
		List<Train> trains = this.controller.getTrains();
		for (int j=0; j<trains.size(); j++) {
			Train t = trains.get(j);
			boolean positioningOK = controller.getLineStatus().putTrain(t, trainPositions[j]);
			if (positioningOK) { 
				centerPane.drawTrain(trainPositions[j], t.getLength(), trainColors.get(t), t.getName());
			}
		}
		this.setCenter(centerPane);
	}
	
	private void updateTrainPanel() {
		TrainLinePane centerPane = new TrainLinePane(this.controller.getLine());
		for (Train t: this.controller.getTrains()) {
			boolean positioningOK = controller.getLineStatus().putTrain(t, this.controller.getLineStatus().getTrainLocation(t));
			if (positioningOK) { 
				centerPane.drawTrain(this.controller.getLineStatus().getTrainLocation(t), t.getLength(), trainColors.get(t), t.getName());
			}
		}
		this.setCenter(centerPane);
	}

	private Color randomColor() {
        Random random = new Random();
        int r = random.nextInt(255);
        int g = random.nextInt(255);
        int b = random.nextInt(255);
        return Color.rgb(r,g,b);
    }
}
