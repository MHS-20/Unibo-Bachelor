package crosswords.persistence;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.Reader;
import java.util.Arrays;

import crosswords.model.Scheme;

public class MyConfigReader implements ConfigReader {

	private int size;
	Scheme board;

	public MyConfigReader(Reader reader) throws BadFileFormatException, IOException {
		BufferedReader rdr = new BufferedReader(reader);
		
			size = parseFirstLine(rdr.readLine());
			board = parseOtherLines(rdr);
		
	}

	private Scheme parseOtherLines(BufferedReader reader) throws IOException, BadFileFormatException {
		String line;
		int row=0;
		Scheme scheme = new Scheme(this.size);
		while((line=reader.readLine())!=null) {
			String[] items = line.split("\\s+");
			if (items.length!=this.getSize()){
				throw new BadFileFormatException("Wrong number of items in line: " + line);
			}
			try {
				int[] numValues = Arrays.stream(items)
											.map(String::trim)
											.map( s -> s.equals("#") ? "0" : s)
											.mapToInt(Integer::parseInt).toArray();
				scheme.setCellRow(row, numValues);
			}
			catch(NumberFormatException e) {
				throw new BadFileFormatException("Bad items in line: " + line);
			}
			row++;
		}
		return scheme;
	}

	private int parseFirstLine(String line) throws BadFileFormatException {
		int n;
		try {
			if (line==null ||  !line.startsWith("DIM ")) {
				throw new BadFileFormatException("Missing DIM keyword in line: " + line);
			}
			String[] items = line.split("\\s+")[1].split("x");
			if (items==null || items.length!=2 ) {
				throw new BadFileFormatException("Bad NxN format in line: " + line);
			}				
			n = Integer.parseInt(items[0].trim());
			if (n != Integer.parseInt(items[1].trim())) {
				throw new BadFileFormatException("Unsquared size NxN in line: " + line);
			}
		} catch (NumberFormatException e) {
			throw new BadFileFormatException("Int expected - " + e);
		}
		return n;
	}

	@Override
	public int getSize() {
		return size;
	}

	@Override
	public Scheme getScheme() {
		return board;
	}

}
