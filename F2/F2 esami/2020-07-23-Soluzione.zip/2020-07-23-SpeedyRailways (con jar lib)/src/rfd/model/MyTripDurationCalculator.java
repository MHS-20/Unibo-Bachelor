package rfd.model;

import java.time.Duration;

public class MyTripDurationCalculator implements TripDurationCalculator {

	// ----------------- Versione con stream --------------------
	/*
	 *  @Override 
	 *  public Duration getDuration(Route route) { 
	 *		double result =  route.getRouteSegments().stream()
	 *									.map(Segment::normalize)
	 *									.flatMap(s -> s.split().stream())
	 *									.mapToDouble(this::getSegmentDuration)
	 *									.sum(); 
	 *		return Duration.ofMinutes(Math.round(result*60)); 
	 *	}
	 */
	
	
	@Override
	public Duration getDuration(Route route) {
		double result = 0;
		for (Segment seg : route.getRouteSegments()) {
			seg = seg.normalize();
			for (Segment innerSeg : seg.split()) {
				result += getSegmentDuration(innerSeg);
			}
		}
		return Duration.ofMinutes(Math.round(result*60));
	}
	
	
	private double getSegmentDuration(Segment segment) {
		return segment.getLength()/segment.getSpeed();
	}
	
}
