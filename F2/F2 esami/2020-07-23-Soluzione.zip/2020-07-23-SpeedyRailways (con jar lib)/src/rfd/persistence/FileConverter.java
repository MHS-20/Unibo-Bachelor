package rfd.persistence;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class FileConverter {
	public static void main(String[] args) throws IOException {
		Optional<List<String>> filenames = RailwayLineReader.getAllLineNames(Paths.get("."));
		for (String filename: filenames.get()) {
			//System.out.println("processing " + filename);
			String[] filenameParts = filename.split("\\.");
			String newFilename = filenameParts[0] + ".newline"; 
			BufferedReader reader = new BufferedReader(new FileReader(filename));
			PrintWriter writer = new PrintWriter(newFilename);
			copyAndProcess(reader, writer);
			reader.close();
			writer.close();
		}
		
	}
/*
	private static void copyAndProcess(BufferedReader reader, PrintWriter writer) throws IOException {
		String line;
		while((line = reader.readLine())!=null) {
			String[] parts = line.split("\\t+"); // '+' needed in case of two or more subsequent tabs
			if(parts.length<2 || parts.length>3 || parts[1].trim().endsWith("HUB") || "0123456789".indexOf(parts[1].trim().charAt(0))>=0) { 
				throw new IllegalArgumentException("badly formatted line");
			}
			String progKm  = parts[0].trim().replace('+',  '.');
			String station = parts[1].trim();
			String hub = (parts.length==3) ? parts[2].trim() : ""; 
			writer.format("%8.2f  %-50s%5s%7d\n",Double.parseDouble(progKm),station,hub,140);
		}
	}
	*/
	
	private static void copyAndProcess(BufferedReader reader, PrintWriter writer) throws IOException {
		String line;
		List<String> lista = new ArrayList<>();
		while((line = reader.readLine())!=null) {
			String[] parts = line.split("\\t+"); // '+' needed in case of two or more subsequent tabs
			if(parts.length<2 || parts.length>3 || parts[1].trim().endsWith("HUB") || "0123456789".indexOf(parts[1].trim().charAt(0))>=0) { 
				throw new IllegalArgumentException("badly formatted line");
			}
			String progKm  = parts[0].trim().replace('+',  '.');
			String station = parts[1].trim();
			String hub = (parts.length==3) ? parts[2].trim() : ""; 
			String formattedLine = String.format("%8.2f  %-50s%5s%7d\n",Double.parseDouble(progKm),station,hub,140);
			//System.out.print(formattedLine);
			lista.add(0,formattedLine);
		}
		lista.forEach(writer::print);
	}
}
