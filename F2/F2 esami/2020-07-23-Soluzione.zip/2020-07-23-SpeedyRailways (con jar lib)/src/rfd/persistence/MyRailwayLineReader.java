package rfd.persistence;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.nio.file.Paths;
import java.text.NumberFormat;
import java.text.ParseException;
import java.util.List;
import java.util.Optional;
import java.util.SortedMap;
import java.util.SortedSet;
import java.util.TreeMap;
import java.util.TreeSet;

import rfd.model.Station;
import rfd.model.RailwayLine;

public class MyRailwayLineReader implements RailwayLineReader {

	@Override
	public RailwayLine getRailwayLine(Reader rdr) throws IOException{
		if (rdr==null) throw new IllegalArgumentException("reader is null");
		BufferedReader reader = new BufferedReader(rdr);
		SortedMap<String,Station> map = new TreeMap<>();
		SortedSet<String> hubs = new TreeSet<>();
		String line;
		int lineLength = 0;
		while((line = reader.readLine())!=null) {
			int firstBoundary  = 8;
			int secondBoundary = line.lastIndexOf(' ');
			String stringProgKm  = line.substring(0,firstBoundary).trim();
			String stringSpeed   = line.substring(secondBoundary).trim();
			String stationName = line.substring(firstBoundary,secondBoundary).trim();
			boolean isHub  = stationName.toUpperCase().endsWith("HUB");
			if (isHub) {
				stationName = stationName.substring(0,stationName.toUpperCase().indexOf("HUB")).trim();
				hubs.add(stationName);
			}
			// Let us check that all lines have the same length
			if(lineLength==0) { 
				lineLength=line.length();
			}
			else if (lineLength!=line.length()) {
				throw new IllegalArgumentException("a line has a different length - bad file format");
			}
			//
			if(stringProgKm.length()==0 || stringSpeed.length()==0 || stationName.length()==0) { 
				throw new IllegalArgumentException("badly formatted line");
			}
			double progKm; int speed; 
			try {
				NumberFormat formatter = NumberFormat.getNumberInstance();
				if (!stringProgKm.matches("\\d+(\\,?\\d+)")) throw new IllegalArgumentException("wrong format in progKm: " + stringProgKm);
				progKm = formatter.parse(stringProgKm).doubleValue();
				speed = Integer.parseInt(stringSpeed);
			}
			catch(NumberFormatException | ParseException e) {
				throw new IllegalArgumentException("wrong format in speed");
			}
			Station station = new Station(stationName,progKm,speed);
			map.put(stationName, station);
		}
		return new RailwayLine(map, hubs);
	}
	
	public static void main(String[] args) throws IOException {
		Optional<List<String>> filenames = RailwayLineReader.getAllLineNames(Paths.get("."));
		MyRailwayLineReader rdr = new MyRailwayLineReader();
		for (String filename: filenames.get()) {
			RailwayLine line = rdr.getRailwayLine(new FileReader(filename));
			System.out.println(line);
		}
		
	}
}