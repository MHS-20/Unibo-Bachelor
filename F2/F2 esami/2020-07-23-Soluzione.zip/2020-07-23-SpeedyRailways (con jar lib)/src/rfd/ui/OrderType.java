package rfd.ui;

public enum OrderType {
	BY_DISTANCE, BY_DURATION;
}
