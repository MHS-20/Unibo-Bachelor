package unident.model;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;

public class Carriera {
	private SortedMap<AttivitaFormativa,List<Esame>> esami;
	private NumberFormat numberFormat; 
	
	public Carriera(Set<AttivitaFormativa> pianoDidattico) {
		esami = new TreeMap<>(Comparator.comparing(AttivitaFormativa::getNome));
		for (AttivitaFormativa af:pianoDidattico) {
			esami.put(af, new ArrayList<>());
		}
		numberFormat = NumberFormat.getInstance();
		numberFormat.setMinimumFractionDigits(2);
		numberFormat.setMaximumFractionDigits(2);
	}
	
	public void registra(Esame esame) {
		AttivitaFormativa af = esame.getAf();
		List<Esame> listaTentativi = esami.get(af);
		if (listaTentativi==null) {
			throw new IllegalArgumentException("Attivit� formativa non presente in carriera");
		}
		if (!listaTentativi.isEmpty()) {
			Esame ultimoEsame = listaTentativi.get(listaTentativi.size()-1);
			if (ultimoEsame.getVoto().getValue().isPresent()) {
				throw new IllegalArgumentException("Esame gi� superato con esito positivo");
			}
			if(ultimoEsame.getDate().isEqual(esame.getDate())) {
				throw new IllegalArgumentException("Ultimo esame registrato ha data identica all'attuale");
			}
			if(ultimoEsame.getDate().isAfter(esame.getDate())) {
				throw new IllegalArgumentException("Ultimo esame registrato ha data successiva all'attuale");
			}
		}
		listaTentativi.add(esame);		
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("Esami sostenuti:"); sb.append(System.lineSeparator());
		for(AttivitaFormativa af:esami.keySet()) {
			if (istanzeDi(af)!=null) {
				for (Esame esame: istanzeDi(af)) {
					sb.append(esame); sb.append(System.lineSeparator());
				}
			}
		}
		sb.append(System.lineSeparator());
		sb.append("Media pesata: " + numberFormat.format(this.mediaPesata()) + "/30");
		sb.append(System.lineSeparator());
		return sb.toString();
	}
	
	public List<Esame> istanzeDi(AttivitaFormativa af){
		return esami.get(af);
	}

	public double mediaPesata() {
		int sommaVotiPesati=0, sommaCfu=0;
		for(AttivitaFormativa af:esami.keySet()) {
			if (istanzeDi(af)!=null) {
				for (Esame esame: istanzeDi(af)) {
					if (esame.getVoto().getValue().isPresent()) {
						sommaCfu += esame.getAf().getCfu();
						sommaVotiPesati += esame.getVoto().getValue().getAsInt()*esame.getAf().getCfu();
					}
				}
			}
		}
		return 1.0*sommaVotiPesati/sommaCfu;
	}

}
