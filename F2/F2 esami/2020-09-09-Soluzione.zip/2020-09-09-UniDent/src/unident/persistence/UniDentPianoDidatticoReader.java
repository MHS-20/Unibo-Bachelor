package unident.persistence;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.Reader;
import java.util.HashSet;
import java.util.Set;

import unident.model.AttivitaFormativa;
import unident.model.Ssd;
import unident.model.Tipologia;


public class UniDentPianoDidatticoReader implements PianoDidatticoReader {

	// 27991	ANALISI MATEMATICA T-1			1	A	MAT/05	9
	// 17268	PROVA FINALE					O	E	3
	// Nota: codice attivit� e periodo devono essere letti ma ignorati
	// Nota: le tipologie E ed F non sono seguite da SSD

	@Override
	public Set<AttivitaFormativa> readAll(Reader rdr) throws IOException {
		if (rdr==null) throw new IllegalArgumentException("reader is null");
		BufferedReader reader = new BufferedReader(rdr);
		Set<AttivitaFormativa> pianoDidattico = new HashSet<>();
		
		String line;
		while((line = reader.readLine())!=null) {
			if (line.isBlank()) continue; // skip blank lines
			String[] items = line.split("\\t+");
			// items[0] = codice attivit� (da ignorare)
			// items[2] = periodo di effettuazione (da ignorare)
			if (items.length<5 || items.length>6) {
				throw new BadFileFormatException("Riga non contiene il giusto numero di elementi: " + line);
			}
			String nome = items[1].trim();
			Tipologia t = null;
			try {
				t = Tipologia.valueOf(items[3]);
			}
			catch(IllegalArgumentException e) {
				throw new BadFileFormatException("Tipologia non valida:" + t);
			}
			Ssd ssd = null; 
			int cfu = 0;
			if (t.ordinal() >= Tipologia.E.ordinal()) {
				ssd = Ssd.SENZASETTORE; cfu = Integer.parseInt(items[4]);
			} else {
				try {
					ssd = Ssd.of(items[4]); cfu = Integer.parseInt(items[5]);
				}
				catch(IndexOutOfBoundsException e) {
					throw new BadFileFormatException("Ssd non valido:" + ssd);
				}
				catch(NumberFormatException e) {
					throw new BadFileFormatException("Cfu non validi:" + cfu);
				}
			}
			AttivitaFormativa afDaInserire = new AttivitaFormativa(nome,t,ssd,cfu);
			boolean buonEsito = pianoDidattico.add(afDaInserire);
			if (!buonEsito) throw new BadFileFormatException("AF duplicata:" + afDaInserire);
		}
		return pianoDidattico;
	}
}