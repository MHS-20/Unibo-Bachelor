package mastermind.model;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public class MasterMind extends Gioco {

	public MasterMind(int maxTentativi, int dim) {
		super(maxTentativi, dim);
	}
		
	@Override 
	protected Risposta calcolaRisposta(Combinazione tentativo) {
		int neri = 0, totali = 0;
		for (int i=0; i<tentativo.dim(); i++) {
			if (tentativo.getPiolo(i).equals(segreta.getPiolo(i))) neri++;
		}
		Map<PioloDiGioco,Integer> occorrenzeSegreta = occorrenze(segreta);
		//	System.err.println("occorrenze nel codice segreto: " + occorrenzeSegreta);
		Map<PioloDiGioco,Integer> occorrenzeTentativo = occorrenze(tentativo);
		//	System.err.println("occorrenze nel tentativo:      " + occorrenzeTentativo);
		for (PioloDiGioco p : PioloDiGioco.values()) {
			totali += Math.min(occorrenzeSegreta.get(p), occorrenzeTentativo.get(p));
		}
		//	System.err.println("totali: " + totali);
		//int bianchi = totali - neri;
		//	System.err.println("bianchi: " + bianchi);
		Risposta r = new Risposta(tentativo.dim());
		for (int i=0; i<neri; i++) r.setPiolo(i, PioloRisposta.NERO);
		for (int i=neri; i<totali; i++) r.setPiolo(i, PioloRisposta.BIANCO);
		return r;
	}
	
	private Map<PioloDiGioco,Integer> occorrenze(Combinazione tentativo){
		Map<PioloDiGioco,Integer> mappa = new HashMap<>();
		for (PioloDiGioco p : PioloDiGioco.values()) mappa.put(p, 0);
		for (int i=0; i<tentativo.dim(); i++) {
			PioloDiGioco pioloAttuale = tentativo.getPiolo(i);
			int frequenzaAttuale = mappa.get(pioloAttuale);
			mappa.put(pioloAttuale, frequenzaAttuale+1);
		}
		return mappa;
	}

	@Override
	protected void sorteggiaCombinazione(Combinazione segreta) {
		Random rnd = new Random();
		for(int i=0; i<this.segreta.dim();i++) {
			int randomIndex = rnd.nextInt(PioloDiGioco.values().length-1)+1; // range 1..6, escludendo 0 (VUOTA)
			segreta.setPiolo(i, PioloDiGioco.values()[randomIndex]);
		}		
	}
}

