package mastermind.model;

public enum PioloRisposta {
	VUOTO, BIANCO, NERO;
}
