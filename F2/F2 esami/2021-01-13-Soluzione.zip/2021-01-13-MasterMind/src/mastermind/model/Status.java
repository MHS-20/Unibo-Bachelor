package mastermind.model;

public enum Status {
	IN_CORSO, PERSO, VITTORIA;
}
