package mastermind.persistence;

public interface ConfigReader {
	int dimensioneCodice();
	int numeroTentativi();
}
