package mastermind.persistence;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.Reader;

public class MyConfigReader implements ConfigReader {
	
	private int dim=0, maxTentativi=0;
	
	public MyConfigReader(Reader reader) throws BadFileFormatException {
		BufferedReader rdr = new BufferedReader(reader);
		String line;
		try {
			while((line=rdr.readLine())!=null) {
				String[] items = line.split("=");
				switch(items[0].trim().toLowerCase()) {
					case "tentativi": 
						maxTentativi=Integer.parseInt(items[1].trim());
						break;
					case "lunghezza combinazione": 
						dim=Integer.parseInt(items[1].trim());
						break;
					default:
						throw new BadFileFormatException("Bad keyword - " + items[0]);
				}
			}
		} catch (NumberFormatException e) {
			throw new BadFileFormatException("Int expected - " + e);
		} catch (IOException e) {
			throw new BadFileFormatException("I/O error - " + e);
		}
	}

	@Override
	public int dimensioneCodice() {
		return dim;
	}

	@Override
	public int numeroTentativi() {
		return maxTentativi;
	}	
	
}
