package ghigliottina.model;

public enum Esatta {
	FIRST,SECOND;
}
