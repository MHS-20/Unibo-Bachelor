package ghigliottina.model;

import java.util.Iterator;
import java.util.List;


public class Ghigliottina implements Iterator<Terna> {
	private List<Terna> terne;
	private Iterator<Terna> iterator;
	private String rispostaEsatta;
	
	public Ghigliottina(List<Terna> terne, String rispostaEsatta) {
		if(terne==null || terne.isEmpty()) throw new IllegalArgumentException("Lista terne nulla o vuota");
		if(rispostaEsatta==null || rispostaEsatta.isBlank()) throw new IllegalArgumentException("Risposta esatta nulla o vuota: |" + rispostaEsatta + "|");
		this.terne=terne;
		this.rispostaEsatta=rispostaEsatta;
		iterator = terne.iterator();
	}
	
	@Override
	public boolean hasNext() {
		return iterator.hasNext();
	}

	@Override
	public Terna next() {
		return iterator.next();
	}

	public List<Terna> getTerne() {
		return terne;
	}

	public String getRispostaEsatta() {
		return rispostaEsatta;
	}

	@Override
	public String toString() {
		return "Ghigliottina [terne=" + terne + ", iterator=" + iterator + ", rispostaEsatta=" + rispostaEsatta + "]";
	}
	
}
