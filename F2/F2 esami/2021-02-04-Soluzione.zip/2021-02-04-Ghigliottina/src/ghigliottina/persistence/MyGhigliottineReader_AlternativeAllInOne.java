package ghigliottina.persistence;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import ghigliottina.model.Esatta;
import ghigliottina.model.Ghigliottina;
import ghigliottina.model.Terna;

public class MyGhigliottineReader_AlternativeAllInOne implements GhigliottineReader {

	private List<Ghigliottina> ghigliottine;

	private Ghigliottina parseOne(BufferedReader reader) throws IOException, BadFileFormatException {
		String line=null, esatta = null;
		List<Terna> terne = new ArrayList<>();
		
		while((line=reader.readLine())!=null) {
			//line contiene o una terna, o la risposta esatta
			if(line.trim().startsWith("Risposta esatta")) {
				String[] items = line.split("=");
				if(items.length!=2) throw new BadFileFormatException("Ghigliottina mal formattata alla riga " + line);
				esatta=items[1].trim();
				line=reader.readLine(); // le lineette
				if(line==null || !line.startsWith("------")) 
					throw new BadFileFormatException("Ghigliottina mal formattata, mancano le lineette");
				// crea e restituisci la ghigliottina completa
				return new Ghigliottina(terne,esatta);
			}
			else {
				String[] items = line.split("/|=");// word1,word2,FIRST|SECOND
				if(items.length!=3) throw new BadFileFormatException("Ghigliottina mal formattata alla riga " + line);
				try {
					Terna terna = new Terna(items[0].trim(),items[1].trim(),Esatta.valueOf(items[2].trim()));
					terne.add(terna);
				}
				catch(IllegalArgumentException e) {
					throw new BadFileFormatException("Ghigliottina mal formattata, manca FIRST|SECOND");
				}
			}
		}
		if(line==null && terne.isEmpty() && esatta==null) return null; // caso fine file: � ok, deve restituire null
		// se invece terne vuote o manca risposta esatta in altre situazioni, c'� un problema
		if(terne.isEmpty()) throw new BadFileFormatException("Ghigliottina mal formattata, mancano le terne");
		if(esatta==null) throw new BadFileFormatException("Ghigliottina mal formattata, manca la risposta esatta");
		return null; // nopn dovrebbe accadere ma indica ghigliottina imperfetta
	}
	
	public List<Ghigliottina> readAll(BufferedReader reader) throws IOException, BadFileFormatException {
		Ghigliottina gh;
		List<Ghigliottina> ghigliottine=new ArrayList<>();;
		while((gh=parseOne(reader))!=null) {
			ghigliottine.add(gh);
		}
		return ghigliottine;
	}

	public List<Ghigliottina> getGhigliottine() {
		return ghigliottine;
	}
	
	public static void main(String[] args) throws FileNotFoundException, BadFileFormatException, IOException {
		GhigliottineReader rdr = new MyGhigliottineReader_AlternativeAllInOne();
		rdr.readAll(new BufferedReader(new FileReader("Ghigliottine.txt")));
	}

}
