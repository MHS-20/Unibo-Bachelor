package ghigliottina.ui;

import java.util.List;

import ghigliottina.model.Ghigliottina;

public interface Controller {

	Ghigliottina sorteggiaGhigliottina();
	List<Ghigliottina> listaGhigliottine();

}
