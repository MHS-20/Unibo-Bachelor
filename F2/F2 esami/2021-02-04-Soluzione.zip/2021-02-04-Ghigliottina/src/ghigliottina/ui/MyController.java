package ghigliottina.ui;

import java.util.List;
import java.util.Random;
import ghigliottina.model.Ghigliottina;

public class MyController implements Controller {

	private List<Ghigliottina> list;
	
	public MyController(List<Ghigliottina> list) {
		this.list=list;
	}

	@Override
	public Ghigliottina sorteggiaGhigliottina() {
		int max=list.size();
		Random rndGen = new Random();
		return list.get(rndGen.nextInt(max));
	}

	public List<Ghigliottina> listaGhigliottine() {
		return list;
	}

}
