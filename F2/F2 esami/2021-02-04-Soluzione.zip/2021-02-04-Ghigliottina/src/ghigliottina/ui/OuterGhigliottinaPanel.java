package ghigliottina.ui;

import ghigliottina.model.Ghigliottina;
import javafx.event.ActionEvent;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;


public class OuterGhigliottinaPanel extends BorderPane {
 
	private GhigliottinaPanel gPanel;
	private TextField txtRispostaUtente, txtRispostaEsatta;
	private Label rightLabel, leftLabel;
	private Button svela;
	private String rispostaEsatta;
	private Controller controller;
	private Ghigliottina gh;
	private int montepremi;
	
	public OuterGhigliottinaPanel(int montepremi, Controller controller) {
		this.controller=controller;
		this.montepremi=montepremi;
		setupGhigliottinaPanel();
		//
		VBox rightBox = new VBox();
		rightBox.setPrefHeight(50);
		rightBox.setPrefWidth(140);
		txtRispostaUtente = new TextField();
		txtRispostaUtente.setFont(Font.font("Arial", FontWeight.BOLD, 14));
		rightLabel = new Label("La tua risposta:");
		rightLabel.setTextFill(Color.WHITE);
		rightLabel.setFont(Font.font("Arial", FontWeight.NORMAL, 14));
		rightBox.getChildren().addAll(rightLabel, txtRispostaUtente);
		VBox.setMargin(rightLabel, new Insets(10, 10, 10, 10));
		VBox.setVgrow(txtRispostaUtente, Priority.ALWAYS);
		//
		VBox leftBox  = new VBox();
		leftBox.setPrefHeight(50);
		leftBox.setPrefWidth(140);
		leftLabel = new Label("La parola segreta:");
		leftLabel.setFont(Font.font("Arial", FontWeight.NORMAL, 14));
		leftLabel.setTextFill(Color.WHITE);
		txtRispostaEsatta = new TextField();
		txtRispostaEsatta.setFont(Font.font("Arial", FontWeight.BOLD, 14));
		txtRispostaEsatta.setDisable(true);
		txtRispostaEsatta.setStyle("-fx-opacity: 0.9;");
		leftBox.getChildren().addAll(leftLabel, txtRispostaEsatta);
		VBox.setMargin(leftLabel, new Insets(10, 10, 10, 10));
		VBox.setVgrow(txtRispostaEsatta, Priority.ALWAYS);
		//
		HBox revealBox = new HBox();
		revealBox.setAlignment(Pos.CENTER);
		revealBox.setStyle("-fx-background-color: blue;");
		svela = new Button("SVELA"); 
		svela.setStyle("-fx-background-color: white;");
		svela.setTextFill(Color.RED);
		svela.setFont(Font.font("Arial", FontWeight.BOLD, 14));
		svela.setOnAction(this::svela);
		svela.setPrefHeight(60);
		revealBox.getChildren().addAll(leftBox,rightBox,svela);
		this.setTop(revealBox);
	}
	
	private void setupGhigliottinaPanel() {
		// initial setup
		gh = controller.sorteggiaGhigliottina();
		this.rispostaEsatta=gh.getRispostaEsatta();
		gPanel = new GhigliottinaPanel(montepremi, gh.getTerne());
		this.setBottom(gPanel);
	}
	
	private void reset() {
		setupGhigliottinaPanel();
		txtRispostaUtente.setText("");
		txtRispostaEsatta.setText("");
	}
	
	private void svela(ActionEvent e) {
		String rispostaUtente = txtRispostaUtente.getText();
		if (rispostaUtente==null || rispostaUtente.isBlank()) {
			alert("Errore", "Risposta mancante", "Non hai scritto alcuna parola valida!");
			return;
		}
		txtRispostaEsatta.setText(rispostaEsatta);
		boolean result = rispostaEsatta.trim().equalsIgnoreCase(rispostaUtente.trim());
		info("Risultato", (result ? "HAI VINTO!" : "RISPOSTA SBAGLIATA :("),
				(result ? "Montepremi: " : "Purtroppo hai perso ") + gPanel.montepremiAsString());
		reset();
	}

	public static void alert(String title, String headerMessage, String contentMessage) {
		Alert alert = new Alert(AlertType.ERROR);
		alert.setTitle(title);
		alert.setHeaderText(headerMessage);
		alert.setContentText(contentMessage);
		alert.showAndWait();
	}
	
	public static void info(String title, String headerMessage, String contentMessage) {
		Alert alert = new Alert(AlertType.INFORMATION);
		alert.setTitle(title);
		alert.setHeaderText(headerMessage);
		alert.setContentText(contentMessage);
		alert.showAndWait();
	}

}
