package it.unibo.paw;

public class Hello {

	public static void main(String[] args) {
		String message = "Hello, world!";
        System.out.println(message);
        
        // Error 1: Variabile non dichiarata
        System.out.println(message);
        
        // Error 2: Chiamata a un metodo inesistente
        int result = add(5, 3);
        System.out.println("Result: " + result);
	}
	
	// Error 3: Metodo non statico referenziato da un contesto statico
	public static int add(int a, int b) {
		return a+b;
	}

}
