package it.unibo.paw.dao;

import java.util.List;

public interface AccertamentoDAO {
	
	// --- CRUD -------------
	public void create(AccertamentoDTO accertamento);

	public AccertamentoDTO read(int id);

	public boolean update(AccertamentoDTO accertamento);

	public boolean delete(int id);	
	// ----------------------------------
	
	public AccertamentoDTO findByCodice(String codice);
	
	public List<AccertamentoDTO> readAllByTipoAccertamento(int tipoAccertamentoId);
	
	// ----------------------------------
	
	public boolean createTable();

	public boolean dropTable();

}
