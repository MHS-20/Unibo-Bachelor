package it.unibo.paw.dao;

import java.io.Serializable;

public class AccertamentoDTO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private int id;
	private String codiceAccertamento;
	private String nome;
	private String descrizione;
	private int idTipoAccertamento;
	
    private boolean alreadyLoaded;
	
	public AccertamentoDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getCodiceAccertamento() {
		return codiceAccertamento;
	}

	public void setCodiceAccertamento(String codiceAccertamento) {
		this.codiceAccertamento = codiceAccertamento;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getDescrizione() {
		return descrizione;
	}

	public void setDescrizione(String descrizione) {
		this.descrizione = descrizione;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	
	public boolean isAlreadyLoaded() {
        return this.alreadyLoaded;
    }

    public void isAlreadyLoaded(boolean loaded) {
        this.alreadyLoaded = loaded;
    }

	public int getIdTipoAccertamento() {
		return idTipoAccertamento;
	}

	public void setIdTipoAccertamento(int idTipoAccertamento) {
		this.idTipoAccertamento = idTipoAccertamento;
	}
	
	
}
