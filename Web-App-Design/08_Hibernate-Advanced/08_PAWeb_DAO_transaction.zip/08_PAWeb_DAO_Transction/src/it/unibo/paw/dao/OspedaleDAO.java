package it.unibo.paw.dao;

import java.util.List;

public interface OspedaleDAO {

	// --- CRUD -------------
	public void create(OspedaleDTO ospedale);

	public OspedaleDTO read(int id);

	public boolean update(OspedaleDTO ospedale);

	public boolean delete(int id);	
	// ----------------------------------
	
	public OspedaleDTO findByName(String nome);
	public List<OspedaleDTO> readAll();
	
	// ----------------------------------
	
	public boolean createTable();

	public boolean dropTable();

}
