package it.unibo.paw.dao;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class OspedaleDTO implements Serializable{

    private static final long serialVersionUID = 1L;
    
    private int id; 
    private String codiceOspedale;
    private String nome;
    private String citta;    
    private String indirizzo;
    
    private List<TipoAccertamentoDTO> tipiAccertamenti;
    
    private boolean alreadyLoaded;
    
    public OspedaleDTO() {
        super();
        this.tipiAccertamenti = new ArrayList<TipoAccertamentoDTO>();
        alreadyLoaded = false;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCitta() {
        return citta;
    }

    public void setCitta(String citta) {
        this.citta = citta;
    }

    public String getIndirizzo() {
        return indirizzo;
    }

    public void setIndirizzo(String indirizzo) {
        this.indirizzo = indirizzo;
    }

    public String getCodiceOspedale() {
        return codiceOspedale;
    }

    public void setCodiceOspedale(String codiceOspedale) {
        this.codiceOspedale = codiceOspedale;
    }

    public List<TipoAccertamentoDTO> getTipiAccertamenti() {
        return tipiAccertamenti;
    }

    public void setTipiAccertamenti(List<TipoAccertamentoDTO> tipiAccertamenti) {
        this.tipiAccertamenti = tipiAccertamenti;
    }
    
    public boolean addTipoAccertamento(TipoAccertamentoDTO ta) {
        return this.tipiAccertamenti.add(ta);
    }
    
    public boolean removeTipoAccertamento(TipoAccertamentoDTO ta) {
        return this.tipiAccertamenti.remove(ta);
    }
    
    public boolean isAlreadyLoaded() {
        return this.alreadyLoaded;
    }

    public void isAlreadyLoaded(boolean loaded) {
        this.alreadyLoaded = loaded;
    }
}
