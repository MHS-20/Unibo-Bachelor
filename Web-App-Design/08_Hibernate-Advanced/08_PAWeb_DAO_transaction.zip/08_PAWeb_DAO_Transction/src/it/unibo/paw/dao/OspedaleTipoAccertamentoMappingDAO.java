package it.unibo.paw.dao;

import java.util.List;

public interface OspedaleTipoAccertamentoMappingDAO {
	
		// --- CRUD -------------
		public void create(int idr, int idp);

		public boolean delete(int idRistorante, int idPiatto);		
		// ----------------------------------
		
		public List<TipoAccertamentoDTO> getTipiAccertamentoFromOspedale(int id);
		public List<OspedaleDTO> getOspedaliFromTipoAccertamento(int id);
		
		// ----------------------------------		
		public boolean createTable();

		public boolean dropTable();
}
