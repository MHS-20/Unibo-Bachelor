package it.unibo.paw.dao;

import java.util.List;

public interface TipoAccertamentoDAO {

	// --- CRUD -------------
	public void create(TipoAccertamentoDTO tipoAccertamento);

	public TipoAccertamentoDTO read(int id);

	public boolean update(TipoAccertamentoDTO tipoAccertamento);

	public boolean delete(int id);	
	// ----------------------------------
	
	public TipoAccertamentoDTO findByCodice(String codice);
	public List<TipoAccertamentoDTO> findByDescrizioneAndOspedale(String descrizione, int idOspedale);

	
	// ----------------------------------
	
	public boolean createTable();

	public boolean dropTable();
	
}
