package it.unibo.paw.dao;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class TipoAccertamentoDTO implements Serializable{

    private static final long serialVersionUID = 1L;
    
    private int id;
    private String codiceTipoAccertamento;
    private String descrizione;
    
    private List<OspedaleDTO> ospedali;
    private List<AccertamentoDTO> accertamenti;

    private boolean areOspedaliLoaded;
    private boolean areAccertamentiLoaded;
    
    public TipoAccertamentoDTO() {
        super();
        this.accertamenti = new ArrayList<AccertamentoDTO>();
        this.ospedali = new ArrayList<OspedaleDTO>();
        
        areOspedaliLoaded = false;
        areAccertamentiLoaded = false;
    }
    
    public int getId() {
        return id;
    }
    
    public void setId(int id) {
        this.id = id;
    }
    
    public String getCodiceTipoAccertamento() {
        return codiceTipoAccertamento;
    }
    
    public void setCodiceTipoAccertamento(String codiceTipoAccertamento) {
        this.codiceTipoAccertamento = codiceTipoAccertamento;
    }
    
    public String getDescrizione() {
        return descrizione;
    }
    
    public void setDescrizione(String descrizione) {
        this.descrizione = descrizione;
    }

    public List<OspedaleDTO> getOspedali() {
        return ospedali;
    }

    public void setOspedali(List<OspedaleDTO> ospedali) {
        this.ospedali = ospedali;
    }

    public List<AccertamentoDTO> getAccertamenti() {
        return accertamenti;
    }

    public void setAccertamenti(List<AccertamentoDTO> accertamenti) {
        this.accertamenti = accertamenti;
    }
    
    public boolean addAccertamento(AccertamentoDTO a) {
        return this.accertamenti.add(a);
    }
    
    public boolean addOspedale(OspedaleDTO o) {
        return this.ospedali.add(o);
    }
    
    public boolean removeOspedale(OspedaleDTO o) {
        return this.ospedali.remove(o);
    }
    
    public boolean removeAccertamento(AccertamentoDTO a) {
        return this.accertamenti.remove(a);
    }
    
    public boolean areOspedaliLoaded() {
        return this.areOspedaliLoaded;
    }

    public void areOspedaliLoaded(boolean loaded) {
        this.areOspedaliLoaded = loaded;
    }

    public boolean areAccertamentiLoaded() {
        return this.areAccertamentiLoaded;
    }

    public void areAccertamentiLoaded(boolean loaded) {
        this.areAccertamentiLoaded = loaded;
    }
}
