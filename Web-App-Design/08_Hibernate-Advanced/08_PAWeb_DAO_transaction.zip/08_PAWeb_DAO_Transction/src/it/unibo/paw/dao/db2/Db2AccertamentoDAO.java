package it.unibo.paw.dao.db2;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import it.unibo.paw.dao.AccertamentoDAO;
import it.unibo.paw.dao.AccertamentoDTO;
import it.unibo.paw.dao.IdBroker;

public class Db2AccertamentoDAO implements AccertamentoDAO {
	
	// === Costanti letterali per non sbagliarsi a scrivere !!! ============================

	private static final String TABLE = "accertamenti";

	// -------------------------------------------------------------------------------------

	private static final String ID = "id";
	private static final String CODICE = "codiceAccertamento";
	private static final String NOME = "nome";
	private static final String DESCRIZIONE = "descrizione";
	private static final String TIPO_ACCERTAMENTO_ID = "tipoAccertamentoId"; // Campo che fa riferimento all'id di TipoAccertamento

	// == STATEMENT SQL ====================================================================

	// INSERT INTO table ( id, codiceAccertamento, nome, descrizione, tipoAccertamentoId ) VALUES ( ?, ?, ?, ?, ? );
	private static final String insert = "INSERT " +
	        "INTO " + TABLE + " ( " +
	        ID + ", " + CODICE + ", " + NOME + ", " + DESCRIZIONE + ", " + TIPO_ACCERTAMENTO_ID + " " +
	        ") " +
	        "VALUES (?,?,?,?,?) ";

	// SELECT * FROM table WHERE id = ?;
	private static final String read = "SELECT * " +
	        "FROM " + TABLE + " " +
	        "WHERE " + ID + " = ? ";

	// SELECT * FROM table WHERE codiceAccertamento = ?;
	private static final String read_by_codice = "SELECT * " +
	        "FROM " + TABLE + " " +
	        "WHERE " + CODICE + " = ? ";
	
	// Seleziona tutti gli accertamenti dato un tipoAccertamento
	private static final String read_all_by_tipoAccertamento = "SELECT * " +
			"FROM " + TABLE + " " +
			"WHERE " + TIPO_ACCERTAMENTO_ID + " = ?";


	// DELETE FROM table WHERE id = ?;
	private static final String delete = "DELETE " +
	        "FROM " + TABLE + " " +
	        "WHERE " + ID + " = ? ";

	// UPDATE table SET codiceAccertamento = ?, nome = ?, descrizione = ?, tipoAccertamentoId = ? WHERE id = ?;
	private static final String update = "UPDATE " + TABLE + " " +
	        "SET " +
	        CODICE + " = ?, " +
	        NOME + " = ?, " +
	        DESCRIZIONE + " = ?, " +
	        TIPO_ACCERTAMENTO_ID + " = ? " +
	        "WHERE " + ID + " = ? ";

	// -------------------------------------------------------------------------------------

	// CREATE table ( id INT NOT NULL PRIMARY KEY, codiceAccertamento VARCHAR(10) NOT NULL UNIQUE, nome VARCHAR(50) NOT NULL, descrizione VARCHAR(100), tipoAccertamentoId INT, FOREIGN KEY (tipoAccertamentoId) REFERENCES TipoAccertamento(id) );
	private static final String create = "CREATE " +
	        "TABLE " + TABLE + " ( " +
	        ID + " INT NOT NULL PRIMARY KEY, " +
	        CODICE + " VARCHAR(10) NOT NULL UNIQUE, " +
	        NOME + " VARCHAR(50) NOT NULL, " +
	        DESCRIZIONE + " VARCHAR(100), " +
	        TIPO_ACCERTAMENTO_ID + " INT, " +
	        "FOREIGN KEY (" + TIPO_ACCERTAMENTO_ID + ") REFERENCES tipiAccertamento(id) " +
	        ") ";

	// DROP table Accertamento;
	private static final String drop = "DROP " +
	        "TABLE " + TABLE + " ";

	
	// === METODI DAO =========================================================================

	@Override
	public void create(AccertamentoDTO accertamento) {
	    Connection conn = Db2DAOFactory.createConnection();

	    if (accertamento == null) {
	        System.out.println("create(): cannot insert a null entry");
	        return;
	    }

	    try {
	        // utilizziamo IdBroker per ottenere l'id dal DB
	        IdBroker broker = new Db2IdBroker();
	        accertamento.setId(broker.newId());

	        // Inizia la transazione: settiamo autocommit a false
	        conn.setAutoCommit(false); // Disabilita autocommit per gestire la transazione manualmente
	        // Settiamo il livello di isolamento 
	        conn.setTransactionIsolation(Connection.TRANSACTION_REPEATABLE_READ);

	        PreparedStatement prep_stmt = conn.prepareStatement(insert);
	        prep_stmt.clearParameters();
	        prep_stmt.setInt(1, accertamento.getId());
	        prep_stmt.setString(2, accertamento.getCodiceAccertamento());
	        prep_stmt.setString(3, accertamento.getNome());	        
	        prep_stmt.setString(4, accertamento.getDescrizione());
	        prep_stmt.setInt(5, accertamento.getIdTipoAccertamento()); 

	        prep_stmt.executeUpdate();

	        // Completamento della transazione: eseguiamo il commit
	        conn.commit();  // Eseguiamo il commit della transazione

	        prep_stmt.close();
	    } catch (Exception e) {
	        System.out.println("create(): failed to insert entry: " + e.getMessage());
	        e.printStackTrace();
	        try {
	            conn.rollback(); // Annulliamo la transazione in caso di errore
	        } catch (SQLException ex) {
	            ex.printStackTrace();
	        }
	    } finally {
	        Db2DAOFactory.closeConnection(conn);
	    }
	}

	@Override
	public AccertamentoDTO read(int accertamentoId) {
	    Connection conn = Db2DAOFactory.createConnection();
	    AccertamentoDTO accertamento = null;

	    try {
	        PreparedStatement prep_stmt = conn.prepareStatement(read);
	        prep_stmt.setInt(1, accertamentoId);
	        ResultSet rs = prep_stmt.executeQuery();

	        if (rs.next()) {
	            accertamento = new AccertamentoDTO();
	            accertamento.setId(rs.getInt(ID));
	            accertamento.setCodiceAccertamento(rs.getString(CODICE));
	            accertamento.setDescrizione(rs.getString(DESCRIZIONE));
	            accertamento.setIdTipoAccertamento(rs.getInt(TIPO_ACCERTAMENTO_ID));
	        }

	        rs.close();
	        prep_stmt.close();
	    } catch (Exception e) {
	        System.out.println("read(): failed to retrieve entry: " + e.getMessage());
	        e.printStackTrace();
	    } finally {
	        Db2DAOFactory.closeConnection(conn);
	    }

	    return accertamento;
	}

	@Override
	public boolean update(AccertamentoDTO accertamento) {
	    Connection conn = Db2DAOFactory.createConnection();

	    if (accertamento == null) {
	        System.out.println("update(): cannot update a null entry");
	        return false;
	    }

	    try {
	        // Inizia la transazione: settiamo autocommit a false
	        conn.setAutoCommit(false); // Disabilita autocommit per gestire la transazione manualmente
	        // Settiamo il livello di isolamento 
	        conn.setTransactionIsolation(Connection.TRANSACTION_REPEATABLE_READ);

	        PreparedStatement prep_stmt = conn.prepareStatement(update);
	        prep_stmt.setString(1, accertamento.getDescrizione());
	        prep_stmt.setInt(2, accertamento.getId());

	        // Completamento della transazione: eseguiamo il commit
	        conn.commit(); // Eseguiamo il commit della transazione

	        prep_stmt.close();
	    } catch (Exception e) {
	        System.out.println("update(): failed to update entry: " + e.getMessage());
	        e.printStackTrace();
	        try {
	            conn.rollback(); // Annulliamo la transazione in caso di errore
	        } catch (SQLException ex) {
	            ex.printStackTrace();
	        }
	    } finally {
	        Db2DAOFactory.closeConnection(conn);
	    }
	    return true;
	}

	@Override
	public boolean delete(int accertamentoId) {
	    if (accertamentoId < 0) {
	        System.out.println("delete(): cannot delete an entry with an invalid id ");
	        return false;
	    }
	    Connection conn = Db2DAOFactory.createConnection();

	    try {
	        // Inizia la transazione: settiamo autocommit a false
	        conn.setAutoCommit(false); // Disabilita autocommit per gestire la transazione manualmente
	        // Settiamo il livello di isolamento 
	        conn.setTransactionIsolation(Connection.TRANSACTION_REPEATABLE_READ);

	        PreparedStatement prep_stmt = conn.prepareStatement(delete);
	        prep_stmt.setInt(1, accertamentoId);

	        prep_stmt.executeUpdate();

	        // Completamento della transazione: eseguiamo il commit
	        conn.commit(); // Eseguiamo il commit della transazione

	        prep_stmt.close();
	    } catch (Exception e) {
	        System.out.println("delete(): failed to delete entry: " + e.getMessage());
	        e.printStackTrace();
	        try {
	            conn.rollback(); // Annulliamo la transazione in caso di errore
	        } catch (SQLException ex) {
	            ex.printStackTrace();
	        }
	    } finally {
	        Db2DAOFactory.closeConnection(conn);
	    }
	    return true;
	}

	@Override
	public AccertamentoDTO findByCodice(String codice) {
	    Connection conn = Db2DAOFactory.createConnection();
	    AccertamentoDTO accertamento = null;

	    try {
	        PreparedStatement prep_stmt = conn.prepareStatement(read_by_codice);
	        prep_stmt.setString(1, codice); 
	        ResultSet rs = prep_stmt.executeQuery();

	        if (rs.next()) {
	            accertamento = new AccertamentoDTO();
	            accertamento.setId(rs.getInt(ID));
	            accertamento.setCodiceAccertamento(rs.getString(CODICE));
	            accertamento.setDescrizione(rs.getString(DESCRIZIONE));
	            accertamento.setIdTipoAccertamento(rs.getInt(TIPO_ACCERTAMENTO_ID));
	        }

	        rs.close();
	        prep_stmt.close();
	    } catch (Exception e) {
	        System.out.println("findByCodice(): failed to retrieve entry by codice: " + e.getMessage());
	        e.printStackTrace();
	    } finally {
	        Db2DAOFactory.closeConnection(conn);
	    }

	    return accertamento;
	}
	
	@Override
	public List<AccertamentoDTO> readAllByTipoAccertamento(int tipoAccertamentoId) {
	    Connection conn = Db2DAOFactory.createConnection();
	    List<AccertamentoDTO> accertamentiList = new ArrayList<>();

	    try {
	        PreparedStatement prep_stmt = conn.prepareStatement(read_all_by_tipoAccertamento);
	        prep_stmt.setInt(1, tipoAccertamentoId); 
	        ResultSet rs = prep_stmt.executeQuery();

	        while (rs.next()) {
	            AccertamentoDTO accertamento = new AccertamentoDTO();
	            accertamento.setId(rs.getInt(ID));
	            accertamento.setCodiceAccertamento(rs.getString(CODICE));
	            accertamento.setDescrizione(rs.getString(DESCRIZIONE));
	            accertamento.setIdTipoAccertamento(rs.getInt(TIPO_ACCERTAMENTO_ID));
	            accertamentiList.add(accertamento); 
	        }

	        rs.close();
	        prep_stmt.close();
	    } catch (Exception e) {
	        System.out.println("readAllByTipoAccertamento(): failed to retrieve entries by tipoAccertamento: " + e.getMessage());
	        e.printStackTrace();
	    } finally {
	        Db2DAOFactory.closeConnection(conn);
	    }

	    return accertamentiList;
	}



	@Override
	public boolean createTable() {
		boolean result = false;
		Connection conn = Db2DAOFactory.createConnection();
		try {
			Statement stmt = conn.createStatement();
			stmt.execute(create);
			result = true;
			stmt.close();
		} catch (Exception e) {
			System.out.println("createTable(): failed to create table '" + TABLE + "': " + e.getMessage());
		} finally {
			Db2DAOFactory.closeConnection(conn);
		}
		return result;
	}

	@Override
	public boolean dropTable() {
		boolean result = false;
		Connection conn = Db2DAOFactory.createConnection();
		try {
			Statement stmt = conn.createStatement();
			stmt.execute(drop);
			result = true;
			stmt.close();
		} catch (Exception e) {
			System.out.println("dropTable(): failed to drop table '" + TABLE + "': " + e.getMessage());
		} finally {
			Db2DAOFactory.closeConnection(conn);
		}
		return result;
	}

}
