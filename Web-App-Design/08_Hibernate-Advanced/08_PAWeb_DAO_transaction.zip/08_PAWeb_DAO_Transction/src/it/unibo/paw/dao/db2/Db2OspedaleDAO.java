package it.unibo.paw.dao.db2;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import it.unibo.paw.dao.IdBroker;
import it.unibo.paw.dao.OspedaleDAO;
import it.unibo.paw.dao.OspedaleDTO;

public class Db2OspedaleDAO implements OspedaleDAO {
	
	//SOLUZIONE CON SEQUENCE
	//Questa soluzione sfrutta le sequenze in db2 per la generazione degli id surrogati
	//per capire di più il funzionamento, guardare classe Db2IdBroker
	

	// === Costanti letterali per non sbagliarsi a scrivere !!! ============================

	private static final String TABLE = "ospedali";

	// -------------------------------------------------------------------------------------

	private static final String ID = "id";
	private static final String CODICE = "codiceOspedale";
	private static final String NOME = "nome";
	private static final String CITTA = "citta";
	private static final String INDIRIZZO = "indirizzo";

	// == STATEMENT SQL ====================================================================

	// INSERT INTO table ( name,description, ...) VALUES ( ?,?, ... );
	private static final String insert = "INSERT " +
			"INTO " + TABLE + " ( " +
			ID + ", " + CODICE + ", " + NOME + ", " + CITTA +", " + INDIRIZZO + " " +
			") " +
			"VALUES (?,?,?,?,?) ";

	// SELECT * FROM table WHERE nome = ?;
	private static final String read_by_name = "SELECT * " +
			"FROM " + TABLE + " " +
			"WHERE " + NOME + " = ? ";

	// SELECT * FROM table WHERE idcolumn = ?;
	private static final String read = "SELECT * " +
			"FROM " + TABLE + " " +
			"WHERE " + ID + " = ? ";
	
	// Select all Ospedali
	private static final String read_all = "SELECT * " +
			"FROM " + TABLE ;


	// DELETE FROM table WHERE idcolumn = ?;
	private static final String delete = "DELETE " +
			"FROM " + TABLE + " " +
			"WHERE " + ID + " = ? ";

	// UPDATE table SET xxxcolumn = ?, ... WHERE idcolumn = ?;
	private static final String update = "UPDATE " + TABLE + " " +
			"SET " +
			NOME + " = ?, " +
			CITTA + " = ?, " +
			INDIRIZZO + " = ? " +
			"WHERE " + ID + " = ? ";
	// -------------------------------------------------------------------------------------

	// CREATE entrytable ( id INT NOT NULL PRIMARY KEY, ... );
	private static final String create = "CREATE " +
			"TABLE " + TABLE + " ( " +
			ID + " INT NOT NULL PRIMARY KEY, " +
			CODICE + " VARCHAR(10) NOT NULL UNIQUE," +
			NOME + " VARCHAR(50) NOT NULL," +
			CITTA + " VARCHAR(50) NOT NULL," +
			INDIRIZZO + " VARCHAR(50) NOT NULL" +
			") ";
	private static final String drop = "DROP " +
			"TABLE " + TABLE + " ";

	// === METODI DAO =========================================================================
	

	@Override
	public void create(OspedaleDTO ospedale) {
	    Connection conn = Db2DAOFactory.createConnection();

	    if (ospedale == null) {
	        System.out.println("create(): cannot insert a null entry");
	        return;
	    }

	    try {
	    	//utilizziamo IdBroker per ottenere l'id dal DB
	        IdBroker broker = new Db2IdBroker();
	        ospedale.setId(broker.newId());

	        // Settiamo l'autocommit a false per iniziare la transazione
	        conn.setAutoCommit(false);
	        // Settiamo il livello di isolamento 
	        conn.setTransactionIsolation(Connection.TRANSACTION_REPEATABLE_READ);

	        PreparedStatement prep_stmt = conn.prepareStatement(insert);
	        prep_stmt.clearParameters();
	        prep_stmt.setInt(1, ospedale.getId());
	        prep_stmt.setString(2, ospedale.getCodiceOspedale());
	        prep_stmt.setString(3, ospedale.getNome());
	        prep_stmt.setString(4, ospedale.getCitta());
	        prep_stmt.setString(5, ospedale.getIndirizzo());
	        
	        prep_stmt.executeUpdate();
	        conn.commit();	//eseguiamo il commit della transazione

	        prep_stmt.close();
	    } catch (Exception e) {
	        System.out.println("create(): failed to insert entry: " + e.getMessage());
	        e.printStackTrace();
	        try {
	            conn.rollback(); // Annulliamo la transazione in caso di errore
	        } catch (SQLException ex) {
	            ex.printStackTrace();
	        }
	    } finally {
	        Db2DAOFactory.closeConnection(conn);
	    }
	}


	@Override
	public OspedaleDTO read(int ospedaleId) {
	    Connection conn = Db2DAOFactory.createConnection();
	    OspedaleDTO ospedale = null;

	    try {
	        PreparedStatement prep_stmt = conn.prepareStatement(read);
	        prep_stmt.setInt(1, ospedaleId);
	        ResultSet rs = prep_stmt.executeQuery();

	        if (rs.next()) {
	            ospedale = new Db2OspedaleDTOProxy();
	            ospedale.setId(rs.getInt(ID));
	            ospedale.setCodiceOspedale(rs.getString(CODICE));
	            ospedale.setNome(rs.getString(NOME));
	            ospedale.setCitta(rs.getString(CITTA));
	            ospedale.setIndirizzo(rs.getString(INDIRIZZO));
	        }

	        rs.close();
	        prep_stmt.close();
	    } catch (Exception e) {
	        System.out.println("read(): failed to retrieve entry: " + e.getMessage());
	        e.printStackTrace();
	    } finally {
	        Db2DAOFactory.closeConnection(conn);
	    }

	    return ospedale;
	}


	@Override
	public boolean update(OspedaleDTO ospedale) {
	    Connection conn = Db2DAOFactory.createConnection();

	    if (ospedale == null) {
	        System.out.println("update(): cannot update a null entry");
	        return false;
	    }

	    try {
	    	// Settiamo l'autocommit a false per iniziare la transazione
	        conn.setAutoCommit(false);
	        // Settiamo il livello di isolamento 
	        conn.setTransactionIsolation(Connection.TRANSACTION_REPEATABLE_READ);

	        PreparedStatement prep_stmt = conn.prepareStatement(update);
	        prep_stmt.setString(1, ospedale.getNome());
	        prep_stmt.setString(2, ospedale.getCitta());
	        prep_stmt.setString(3, ospedale.getIndirizzo());
	        prep_stmt.setInt(4, ospedale.getId());

            conn.commit();	//eseguiamo il commit della transazione

	        prep_stmt.close();
	    } catch (Exception e) {
	        System.out.println("update(): failed to update entry: " + e.getMessage());
	        e.printStackTrace();
	        try {
	            conn.rollback();	// Annulliamo la transazione in caso di errore
	        } catch (SQLException ex) {
	            ex.printStackTrace();
	        }
	    } finally {
	        Db2DAOFactory.closeConnection(conn);
	    }
	    return true;
	}


	@Override
	public boolean delete(int ospedaleId) {
		
		if (ospedaleId < 0) {
			System.out.println("delete(): cannot delete an entry with an invalid id ");
			return false;
		}
	    Connection conn = Db2DAOFactory.createConnection();

	    try {
	    	// Settiamo l'autocommit a false per iniziare la transazione
	        conn.setAutoCommit(false);
	        // Settiamo il livello di isolamento 
	        conn.setTransactionIsolation(Connection.TRANSACTION_REPEATABLE_READ);

	        PreparedStatement prep_stmt = conn.prepareStatement(delete);
	        prep_stmt.setInt(1, ospedaleId);

	        prep_stmt.executeUpdate();
	        conn.commit();	//eseguiamo il commit della transazione

	        prep_stmt.close();
	    } catch (Exception e) {
	        System.out.println("delete(): failed to delete entry: " + e.getMessage());
	        e.printStackTrace();
	        try {
	            conn.rollback();	// Annulliamo la transazione in caso di errore
	        } catch (SQLException ex) {
	            ex.printStackTrace();
	        }
	    } finally {
	        Db2DAOFactory.closeConnection(conn);
	    }
	    return true;
	}


	@Override
	public OspedaleDTO findByName(String name) {
	    Connection conn = Db2DAOFactory.createConnection();
	    OspedaleDTO ospedale = null;

	    try {
	        PreparedStatement prep_stmt = conn.prepareStatement(read_by_name);
	        prep_stmt.setString(1, name); 
	        ResultSet rs = prep_stmt.executeQuery(); 

	        if (rs.next()) {
	        	ospedale = new Db2OspedaleDTOProxy();
	            ospedale.setId(rs.getInt(ID));
	            ospedale.setCodiceOspedale(rs.getString(CODICE));
	            ospedale.setNome(rs.getString(NOME));
	            ospedale.setCitta(rs.getString(CITTA));
	            ospedale.setIndirizzo(rs.getString(INDIRIZZO));
	        }

	        rs.close();
	        prep_stmt.close();
	    } catch (Exception e) {
	        System.out.println("findByName(): failed to retrieve entry by name: " + e.getMessage());
	        e.printStackTrace();
	    } finally {
	        Db2DAOFactory.closeConnection(conn);
	    }

	    return ospedale;
	}
	
	@Override
	public List<OspedaleDTO> readAll() {
	    Connection conn = Db2DAOFactory.createConnection();
	    List<OspedaleDTO> result = new ArrayList<OspedaleDTO>();

	    try {
	    	PreparedStatement prep_stmt = conn.prepareStatement(read_all);
			prep_stmt.clearParameters();
			ResultSet rs = prep_stmt.executeQuery();

	        while(rs.next()) {
	        	OspedaleDTO ospedale = new Db2OspedaleDTOProxy();
	            ospedale.setId(rs.getInt(ID));
	            ospedale.setCodiceOspedale(rs.getString(CODICE));
	            ospedale.setNome(rs.getString(NOME));
	            ospedale.setCitta(rs.getString(CITTA));
	            ospedale.setIndirizzo(rs.getString(INDIRIZZO));
	            
	            result.add(ospedale);
	        }

	        rs.close();
	        prep_stmt.close();
	    } catch (Exception e) {
	        System.out.println("findByName(): failed to retrieve entry by name: " + e.getMessage());
	        e.printStackTrace();
	    } finally {
	        Db2DAOFactory.closeConnection(conn);
	    }

	    return result;
	}


	@Override
	public boolean createTable() {
		boolean result = false;
		Connection conn = Db2DAOFactory.createConnection();
		try {
			Statement stmt = conn.createStatement();
			stmt.execute(create);
			result = true;
			stmt.close();
		} catch (Exception e) {
			System.out.println("createTable(): failed to create table '" + TABLE + "': " + e.getMessage());
		} finally {
			Db2DAOFactory.closeConnection(conn);
		}
		return result;
	}

	@Override
	public boolean dropTable() {
		boolean result = false;
		Connection conn = Db2DAOFactory.createConnection();
		try {
			Statement stmt = conn.createStatement();
			stmt.execute(drop);
			result = true;
			stmt.close();
		} catch (Exception e) {
			System.out.println("dropTable(): failed to drop table '" + TABLE + "': " + e.getMessage());
		} finally {
			Db2DAOFactory.closeConnection(conn);
		}
		return result;
	}

}
