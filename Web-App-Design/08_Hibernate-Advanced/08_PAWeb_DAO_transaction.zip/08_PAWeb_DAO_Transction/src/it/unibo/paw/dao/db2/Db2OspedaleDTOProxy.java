package it.unibo.paw.dao.db2;

import it.unibo.paw.dao.OspedaleDTO;
import it.unibo.paw.dao.OspedaleTipoAccertamentoMappingDAO;
import it.unibo.paw.dao.TipoAccertamentoDTO;

import java.util.List;

public class Db2OspedaleDTOProxy extends OspedaleDTO {

    private static final long serialVersionUID = 1L;

    public Db2OspedaleDTOProxy() {
        super();
    }

    @Override
    public List<TipoAccertamentoDTO> getTipiAccertamenti() {
        if (isAlreadyLoaded()) {
            return super.getTipiAccertamenti();
        } else {
            OspedaleTipoAccertamentoMappingDAO otam = new Db2OspedaliTipiAccertamentoMappingDAO();
            setTipiAccertamenti(otam.getTipiAccertamentoFromOspedale(this.getId()));
            isAlreadyLoaded(true);
            return getTipiAccertamenti();
        }
    }
}