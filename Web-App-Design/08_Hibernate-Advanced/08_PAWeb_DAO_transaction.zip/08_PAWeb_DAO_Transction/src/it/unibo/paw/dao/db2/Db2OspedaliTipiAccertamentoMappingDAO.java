package it.unibo.paw.dao.db2;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import it.unibo.paw.dao.OspedaleDTO;
import it.unibo.paw.dao.OspedaleTipoAccertamentoMappingDAO;
import it.unibo.paw.dao.TipoAccertamentoDTO;

public class Db2OspedaliTipiAccertamentoMappingDAO implements OspedaleTipoAccertamentoMappingDAO {
    
	// === Costanti letterali per non sbagliarsi a scrivere !!! ============================
    private static final String TABLE = "ospedali_tipi_accertamento";
    private static final String ID_O = "idOspedale";
    private static final String ID_T = "idTipoAccertamento";
    
	// == STATEMENT SQL ====================================================================
    
    // inserimento e eliminazione associazioni
    private static final String insert = "INSERT INTO " + TABLE + " (" + ID_O + ", " + ID_T + ") VALUES (?, ?)";
    private static final String delete = "DELETE FROM " + TABLE + " WHERE " + ID_O + " = ? AND " + ID_T + " = ?";
    
    //Query SQL
    private static final String read_by_ospedale_id = 
    	    "SELECT * FROM " + TABLE + " ota " +
    	    "JOIN tipiAccertamento ta ON ota." + ID_T + " = ta.id " +
    	    "WHERE ota." + ID_O + " = ?";

    private static final String read_by_tipo_accertamento_id = 
    	    "SELECT * FROM " + TABLE + " AS ota " +
    	    "JOIN ospedali AS o ON ota." + ID_O + " = o.id " +
    	    "WHERE ota." + ID_T + " = ?";
        
    //create and drop table
    private static final String create_table = "CREATE TABLE " + TABLE + " (" +
            ID_O + " INT NOT NULL, " +
            ID_T + " INT NOT NULL, " +
            "PRIMARY KEY (" + ID_O + "," + ID_T + "), " +
            "FOREIGN KEY (" + ID_O + ") REFERENCES ospedali(id) ON DELETE CASCADE, " +
            "FOREIGN KEY (" + ID_T + ") REFERENCES tipiAccertamento(id) ON DELETE CASCADE)";
    private static final String drop_table = "DROP TABLE " + TABLE;
    
    
    
    // Metodo per la creazione della tabella
    @Override
    public boolean createTable() {
        try (Connection conn = Db2DAOFactory.createConnection(); 
             Statement stmt = conn.createStatement()) {
            stmt.executeUpdate(create_table);
            return true;
        } catch (SQLException e) {
            System.out.println("Errore durante la creazione della tabella: " + e.getMessage());
            return false;
        }
    }
    
    // Metodo per la rimozione della tabella
    @Override
    public boolean dropTable() {
        try (Connection conn = Db2DAOFactory.createConnection(); 
             Statement stmt = conn.createStatement()) {
            stmt.executeUpdate(drop_table);
            return true;
        } catch (SQLException e) {
            System.out.println("Errore durante la rimozione della tabella: " + e.getMessage());
            return false;
        }
    }

    // Metodo per inserire una coppia Ospedale-TipoAccertamento
    @Override
    public void create(int idOspedale, int idTipoAccertamento) {
    	Connection conn = Db2DAOFactory.createConnection();
        try {
        	// Inizia la transazione: settiamo autocommit a false
	        conn.setAutoCommit(false); // Disabilita autocommit per gestire la transazione manualmente
	        // Settiamo il livello di isolamento 
	        conn.setTransactionIsolation(Connection.TRANSACTION_REPEATABLE_READ);
        	
        	PreparedStatement prep_stmt = conn.prepareStatement(insert);
            prep_stmt.setInt(1, idOspedale);
            prep_stmt.setInt(2, idTipoAccertamento);
            prep_stmt.executeUpdate();
            
            // Completamento della transazione: eseguiamo il commit
	        conn.commit();  // Eseguiamo il commit della transazione
            
	        prep_stmt.close();
        } catch (Exception e) {
	        System.out.println("create(): failed to insert entry: " + e.getMessage());
	        e.printStackTrace();
	        try {
	            conn.rollback(); // Annulliamo la transazione in caso di errore
	        } catch (SQLException ex) {
	            ex.printStackTrace();
	        }
	    } finally {
	        Db2DAOFactory.closeConnection(conn);
	    }
    }

    // Metodo per eliminare una coppia Ospedale-TipoAccertamento
    @Override
    public boolean delete(int idOspedale, int idTipoAccertamento) {
    	
    	if(idOspedale <0 || idTipoAccertamento <0) {
    		System.out.println("delete(): cannot delete an entry with an invalid id ");
	        return false;
    	}
    	
    	Connection conn = Db2DAOFactory.createConnection();
        try{
        	// Inizia la transazione: settiamo autocommit a false
	        conn.setAutoCommit(false); // Disabilita autocommit per gestire la transazione manualmente
	        // Settiamo il livello di isolamento 
	        conn.setTransactionIsolation(Connection.TRANSACTION_REPEATABLE_READ);
	        
        	PreparedStatement prep_stmt = conn.prepareStatement(delete);
            prep_stmt.setInt(1, idOspedale);
            prep_stmt.setInt(2, idTipoAccertamento);
            
            // Completamento della transazione: eseguiamo il commit
	        conn.commit(); // Eseguiamo il commit della transazione

	        prep_stmt.close();
            
        } catch (Exception e) {
	        System.out.println("delete(): failed to delete entry: " + e.getMessage());
	        e.printStackTrace();
	        try {
	            conn.rollback(); // Annulliamo la transazione in caso di errore
	        } catch (SQLException ex) {
	            ex.printStackTrace();
	        }
	    } finally {
	        Db2DAOFactory.closeConnection(conn);
	    }
	    return true;
    }

    // Metodo per recuperare tutti i tipi di accertamento per un ospedale
    @Override
    public List<TipoAccertamentoDTO> getTipiAccertamentoFromOspedale(int idOspedale) {
    	Connection conn = Db2DAOFactory.createConnection();
    	List<TipoAccertamentoDTO> tipiAccertamento = new ArrayList<>();
        try {
        	PreparedStatement prep_stmt = conn.prepareStatement(read_by_ospedale_id);
            prep_stmt.setInt(1, idOspedale);
            ResultSet rs = prep_stmt.executeQuery();
            while (rs.next()) {
                TipoAccertamentoDTO tipo = new Db2TipoAccertamentoDTOProxy();
                tipo.setId(rs.getInt("idTipoAccertamento"));
                tipo.setCodiceTipoAccertamento(rs.getString("codiceTipoAccertamento"));
                tipo.setDescrizione(rs.getString("descrizione"));
                tipiAccertamento.add(tipo);
            }
            rs.close();
	        prep_stmt.close();
        } catch (Exception e) {
	        System.out.println("read(): failed to retrieve entry: " + e.getMessage());
	        e.printStackTrace();
	    } finally {
	        Db2DAOFactory.closeConnection(conn);
	    }
        
        return tipiAccertamento;
    }

    // Metodo per recuperare tutti gli ospedali per un tipo di accertamento
    @Override
    public List<OspedaleDTO> getOspedaliFromTipoAccertamento(int idTipoAccertamento) {
    	Connection conn = Db2DAOFactory.createConnection();
    	List<OspedaleDTO> ospedali = new ArrayList<>();
    	
        try {
        	PreparedStatement prep_stmt = conn.prepareStatement(read_by_tipo_accertamento_id);
            prep_stmt.setInt(1, idTipoAccertamento);
            ResultSet rs = prep_stmt.executeQuery();
            while (rs.next()) {
                OspedaleDTO ospedale = new Db2OspedaleDTOProxy();
                ospedale.setId(rs.getInt("idOspedale"));
                ospedale.setCodiceOspedale(rs.getString("codiceOspedale"));
                ospedale.setNome(rs.getString("nome"));
                ospedale.setCitta(rs.getString("citta"));
                ospedale.setIndirizzo(rs.getString("indirizzo"));
                ospedali.add(ospedale);
            }
            rs.close();
	        prep_stmt.close();
        } catch (Exception e) {
	        System.out.println("read(): failed to retrieve entry: " + e.getMessage());
	        e.printStackTrace();
	    } finally {
	        Db2DAOFactory.closeConnection(conn);
	    }
        
        return ospedali;
    }
}
