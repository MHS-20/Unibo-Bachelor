package it.unibo.paw.dao.db2;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import it.unibo.paw.dao.IdBroker;
import it.unibo.paw.dao.TipoAccertamentoDAO;
import it.unibo.paw.dao.TipoAccertamentoDTO;

public class Db2TipoAccertamentoDAO implements TipoAccertamentoDAO {
	
	// === Costanti letterali per non sbagliarsi a scrivere !!! ============================

	private static final String TABLE = "tipiAccertamento";

	// -------------------------------------------------------------------------------------

	private static final String ID = "id";
	private static final String CODICE = "codiceTipoAccertamento";
	private static final String DESCRIZIONE = "descrizione";

	// == STATEMENT SQL ====================================================================

	// INSERT INTO table ( id, codiceTipoAccertamento, descrizione ) VALUES ( ?, ?, ? );
	private static final String insert = "INSERT " +
	        "INTO " + TABLE + " ( " +
	        ID + ", " + CODICE + ", " + DESCRIZIONE + " " +
	        ") " +
	        "VALUES (?,?,?) ";

	// SELECT * FROM table WHERE id = ?;
	private static final String read = "SELECT * " +
	        "FROM " + TABLE + " " +
	        "WHERE " + ID + " = ? ";

	// SELECT * FROM table WHERE codiceTipoAccertamento = ?;
	private static final String read_by_codice = "SELECT * " +
	        "FROM " + TABLE + " " +
	        "WHERE " + CODICE + " = ? ";
	
	// Ricerca per descrizione ed ospedale (ci serve per la query)
	private static final String read_by_descrizione_e_ospedale = 
		    "SELECT t.* " +
		    "FROM " + TABLE + " t " +
		    "JOIN ospedali_tipi_accertamento ota ON t." + ID + " = ota.idTipoAccertamento " +
		    "WHERE t." + DESCRIZIONE + " = ? AND ota.idOspedale = ?";

	// DELETE FROM table WHERE id = ?;
	private static final String delete = "DELETE " +
	        "FROM " + TABLE + " " +
	        "WHERE " + ID + " = ? ";

	// UPDATE table SET descrizione = ? WHERE id = ?;
	private static final String update = "UPDATE " + TABLE + " " +
	        "SET " +
	        DESCRIZIONE + " = ? " +
	        "WHERE " + ID + " = ? ";

	// -------------------------------------------------------------------------------------

	// CREATE table 
	private static final String create = "CREATE " +
	        "TABLE " + TABLE + " ( " +
	        ID + " INT NOT NULL PRIMARY KEY, " +
	        CODICE + " VARCHAR(10) NOT NULL UNIQUE, " +
	        DESCRIZIONE + " VARCHAR(100) NOT NULL " +
	        ") ";

	// DROP table TipoAccertamento;
	private static final String drop = "DROP " +
	        "TABLE " + TABLE + " ";

	
	// === METODI DAO =========================================================================

	@Override
	public void create(TipoAccertamentoDTO tipoAccertamento) {
	    Connection conn = Db2DAOFactory.createConnection();

	    if (tipoAccertamento == null) {
	        System.out.println("create(): cannot insert a null entry");
	        return;
	    }

	    try {
	        // utilizziamo IdBroker per ottenere l'id dal DB
	        IdBroker broker = new Db2IdBroker();
	        tipoAccertamento.setId(broker.newId());

	        // Inizia la transazione: settiamo autocommit a false
	        conn.setAutoCommit(false); // Disabilita autocommit per gestire la transazione manualmente
	        // Settiamo il livello di isolamento 
	        conn.setTransactionIsolation(Connection.TRANSACTION_REPEATABLE_READ);

	        PreparedStatement prep_stmt = conn.prepareStatement(insert);
	        prep_stmt.clearParameters();
	        prep_stmt.setInt(1, tipoAccertamento.getId());
	        prep_stmt.setString(2, tipoAccertamento.getCodiceTipoAccertamento());
	        prep_stmt.setString(3, tipoAccertamento.getDescrizione());

	        prep_stmt.executeUpdate();

	        // Completamento della transazione: eseguiamo il commit
	        conn.commit();  // Eseguiamo il commit della transazione

	        prep_stmt.close();
	    } catch (Exception e) {
	        System.out.println("create(): failed to insert entry: " + e.getMessage());
	        e.printStackTrace();
	        try {
	            conn.rollback(); // Annulliamo la transazione in caso di errore
	        } catch (SQLException ex) {
	            ex.printStackTrace();
	        }
	    } finally {
	        Db2DAOFactory.closeConnection(conn);
	    }
	}

	@Override
	public TipoAccertamentoDTO read(int tipoAccertamentoId) {
	    Connection conn = Db2DAOFactory.createConnection();
	    TipoAccertamentoDTO tipoAccertamento = null;

	    try {
	        PreparedStatement prep_stmt = conn.prepareStatement(read);
	        prep_stmt.setInt(1, tipoAccertamentoId);
	        ResultSet rs = prep_stmt.executeQuery();

	        if (rs.next()) {
	            // Utilizziamo il proxy per TipoAccertamentoDTO
	            tipoAccertamento = new Db2TipoAccertamentoDTOProxy();
	            tipoAccertamento.setId(rs.getInt(ID));
	            tipoAccertamento.setCodiceTipoAccertamento(rs.getString(CODICE));
	            tipoAccertamento.setDescrizione(rs.getString(DESCRIZIONE));
	        }

	        rs.close();
	        prep_stmt.close();
	    } catch (Exception e) {
	        System.out.println("read(): failed to retrieve entry: " + e.getMessage());
	        e.printStackTrace();
	    } finally {
	        Db2DAOFactory.closeConnection(conn);
	    }

	    return tipoAccertamento;
	}

	@Override
	public boolean update(TipoAccertamentoDTO tipoAccertamento) {
	    Connection conn = Db2DAOFactory.createConnection();

	    if (tipoAccertamento == null) {
	        System.out.println("update(): cannot update a null entry");
	        return false;
	    }

	    try {
	        // Inizia la transazione: settiamo autocommit a false
	        conn.setAutoCommit(false); // Disabilita autocommit per gestire la transazione manualmente
	        // Settiamo il livello di isolamento 
	        conn.setTransactionIsolation(Connection.TRANSACTION_REPEATABLE_READ);

	        PreparedStatement prep_stmt = conn.prepareStatement(update);
	        prep_stmt.setString(1, tipoAccertamento.getDescrizione());
	        prep_stmt.setInt(2, tipoAccertamento.getId());

	        // Completamento della transazione: eseguiamo il commit
	        conn.commit(); // Eseguiamo il commit della transazione

	        prep_stmt.close();
	    } catch (Exception e) {
	        System.out.println("update(): failed to update entry: " + e.getMessage());
	        e.printStackTrace();
	        try {
	            conn.rollback(); // Annulliamo la transazione in caso di errore
	        } catch (SQLException ex) {
	            ex.printStackTrace();
	        }
	    } finally {
	        Db2DAOFactory.closeConnection(conn);
	    }
	    return true;
	}

	@Override
	public boolean delete(int tipoAccertamentoId) {
	    if (tipoAccertamentoId < 0) {
	        System.out.println("delete(): cannot delete an entry with an invalid id ");
	        return false;
	    }
	    Connection conn = Db2DAOFactory.createConnection();

	    try {
	        // Inizia la transazione: settiamo autocommit a false
	        conn.setAutoCommit(false); // Disabilita autocommit per gestire la transazione manualmente
	        // Settiamo il livello di isolamento 
	        conn.setTransactionIsolation(Connection.TRANSACTION_REPEATABLE_READ);

	        PreparedStatement prep_stmt = conn.prepareStatement(delete);
	        prep_stmt.setInt(1, tipoAccertamentoId);

	        prep_stmt.executeUpdate();

	        // Completamento della transazione: eseguiamo il commit
	        conn.commit(); // Eseguiamo il commit della transazione

	        prep_stmt.close();
	    } catch (Exception e) {
	        System.out.println("delete(): failed to delete entry: " + e.getMessage());
	        e.printStackTrace();
	        try {
	            conn.rollback(); // Annulliamo la transazione in caso di errore
	        } catch (SQLException ex) {
	            ex.printStackTrace();
	        }
	    } finally {
	        Db2DAOFactory.closeConnection(conn);
	    }
	    return true;
	}

	@Override
	public TipoAccertamentoDTO findByCodice(String codice) {
	    Connection conn = Db2DAOFactory.createConnection();
	    TipoAccertamentoDTO tipoAccertamento = null;

	    try {
	        PreparedStatement prep_stmt = conn.prepareStatement(read_by_codice);
	        prep_stmt.setString(1, codice); 
	        ResultSet rs = prep_stmt.executeQuery(); 

	        if (rs.next()) {
	            // Utilizziamo il proxy per TipoAccertamentoDTO
	        	tipoAccertamento = new Db2TipoAccertamentoDTOProxy();
	            tipoAccertamento.setId(rs.getInt(ID));
	            tipoAccertamento.setCodiceTipoAccertamento(rs.getString(CODICE));
	            tipoAccertamento.setDescrizione(rs.getString(DESCRIZIONE));
	        }
	        
	        rs.close();
	        prep_stmt.close();
	    } catch (Exception e) {
	        System.out.println("findByCodice(): failed to retrieve entry by codice: " + e.getMessage());
	        e.printStackTrace();
	    } finally {
	        Db2DAOFactory.closeConnection(conn);
	    }

	    return tipoAccertamento;
	}
	
	@Override
    public List<TipoAccertamentoDTO> findByDescrizioneAndOspedale(String descrizione, int idOspedale) {
    	Connection conn = Db2DAOFactory.createConnection();
    	List<TipoAccertamentoDTO> resultList = new ArrayList<>();

        try { 
        	PreparedStatement prep_stmt = conn.prepareStatement(read_by_descrizione_e_ospedale);
			prep_stmt.setString(1, descrizione);  
			prep_stmt.setInt(2, idOspedale);      
 
            ResultSet rs = prep_stmt.executeQuery();
            
            while (rs.next()) {
                TipoAccertamentoDTO tipoAccertamento = new Db2TipoAccertamentoDTOProxy();
                tipoAccertamento.setId(rs.getInt(ID));
	            tipoAccertamento.setCodiceTipoAccertamento(rs.getString(CODICE));
	            tipoAccertamento.setDescrizione(rs.getString(DESCRIZIONE));

                resultList.add(tipoAccertamento);
            }
            
            rs.close();
	        prep_stmt.close();
        } catch (Exception e) {
	        System.out.println("find_by_descrizione(): failed to retrieve entry by descrizione: " + e.getMessage());
	        e.printStackTrace();
	    } finally {
	        Db2DAOFactory.closeConnection(conn);
	    }

        return resultList;
    }

	@Override
	public boolean createTable() {
		boolean result = false;
		Connection conn = Db2DAOFactory.createConnection();
		try {
			Statement stmt = conn.createStatement();
			stmt.execute(create);
			result = true;
			stmt.close();
		} catch (Exception e) {
			System.out.println("createTable(): failed to create table '" + TABLE + "': " + e.getMessage());
		} finally {
			Db2DAOFactory.closeConnection(conn);
		}
		return result;
	}

	@Override
	public boolean dropTable() {
		boolean result = false;
		Connection conn = Db2DAOFactory.createConnection();
		try {
			Statement stmt = conn.createStatement();
			stmt.execute(drop);
			result = true;
			stmt.close();
		} catch (Exception e) {
			System.out.println("dropTable(): failed to drop table '" + TABLE + "': " + e.getMessage());
		} finally {
			Db2DAOFactory.closeConnection(conn);
		}
		return result;
	}

}
