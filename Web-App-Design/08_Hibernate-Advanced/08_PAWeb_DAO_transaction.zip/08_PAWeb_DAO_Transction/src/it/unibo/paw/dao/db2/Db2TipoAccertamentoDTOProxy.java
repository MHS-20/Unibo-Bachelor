package it.unibo.paw.dao.db2;

import it.unibo.paw.dao.AccertamentoDAO;
import it.unibo.paw.dao.AccertamentoDTO;
import it.unibo.paw.dao.OspedaleDTO;
import it.unibo.paw.dao.OspedaleTipoAccertamentoMappingDAO;
import it.unibo.paw.dao.TipoAccertamentoDTO;

import java.util.List;

public class Db2TipoAccertamentoDTOProxy extends TipoAccertamentoDTO {

    private static final long serialVersionUID = 1L;

    public Db2TipoAccertamentoDTOProxy() {
        super();
    }

    @Override
    public List<AccertamentoDTO> getAccertamenti() {
        if (areAccertamentiLoaded()) {
            return super.getAccertamenti();
        } else {
            AccertamentoDAO adao = new Db2AccertamentoDAO();
            setAccertamenti(adao.readAllByTipoAccertamento(this.getId()));
            areAccertamentiLoaded(true);
            return getAccertamenti();
        }
    }
    
    @Override
    public List<OspedaleDTO> getOspedali() {
        if (areOspedaliLoaded()) {
            return super.getOspedali();
        } else {
            // Assuming there is a DAO method that gets ospedali for a tipo accertamento
            OspedaleTipoAccertamentoMappingDAO ospedaleDao = new Db2OspedaliTipiAccertamentoMappingDAO();
            setOspedali(ospedaleDao.getOspedaliFromTipoAccertamento(this.getId()));
            areOspedaliLoaded(true);
            return getOspedali();
        }
    }
}
