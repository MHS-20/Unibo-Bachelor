package it.unibo.paw.dao.db2;

public class PersistenceException extends Exception {

    /**
     * 
     */
    private static final long serialVersionUID = -3835068319580102263L;

    public PersistenceException(String msg){
        super(msg);
    } 
    
}
