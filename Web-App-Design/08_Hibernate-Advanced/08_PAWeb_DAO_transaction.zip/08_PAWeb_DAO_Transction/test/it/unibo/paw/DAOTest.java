package it.unibo.paw;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Test;

import it.unibo.paw.dao.AccertamentoDAO;
import it.unibo.paw.dao.AccertamentoDTO;
import it.unibo.paw.dao.DAOFactory;
import it.unibo.paw.dao.OspedaleDAO;
import it.unibo.paw.dao.OspedaleDTO;
import it.unibo.paw.dao.OspedaleTipoAccertamentoMappingDAO;
import it.unibo.paw.dao.TipoAccertamentoDAO;
import it.unibo.paw.dao.TipoAccertamentoDTO;
import it.unibo.paw.dao.db2.Db2OspedaliTipiAccertamentoMappingDAO;

public class DAOTest {

	public static void main(String[] args) {
	    // Inizializzazione DAO Factory
		int DB2 = 0;
	    DAOFactory daoFactoryInstance = DAOFactory.getDAOFactory(DB2);
	    
	    // Ospedali
	    OspedaleDAO ospedaleDAO = daoFactoryInstance.getOspedaleDAO();
	    ospedaleDAO.dropTable();
	    ospedaleDAO.createTable();

	    OspedaleDTO o1 = new OspedaleDTO();
	    o1.setCodiceOspedale("OS001");
	    o1.setNome("Ospedale Maggiore");
	    o1.setCitta("Bologna");
	    o1.setIndirizzo("Via Emilia, 120");
	    ospedaleDAO.create(o1);
	    System.out.println("Inserito ospedale con ID: " + o1.getId());

	    OspedaleDTO o2 = new OspedaleDTO();
	    o2.setCodiceOspedale("OS002");
	    o2.setNome("Ospedale di San Giovanni");
	    o2.setCitta("Milano");
	    o2.setIndirizzo("Viale della Repubblica, 30");
	    ospedaleDAO.create(o2);
	    System.out.println("Inserito ospedale con ID: " + o2.getId());

	    OspedaleDTO o3 = new OspedaleDTO();
	    o3.setCodiceOspedale("OS003");  
	    o3.setNome("Policlinico Sant'Orsola-Malpighi");
	    o3.setCitta("Bologna");  
	    o3.setIndirizzo("Via Massarenti, 9");  
	    ospedaleDAO.create(o3);
	    System.out.println("Inserito ospedale con ID: " + o3.getId());
	    
	    // Ricerca per Ospedale (per nome)
	    String nomeRicercaOspedale = "Ospedale Maggiore";  
	    OspedaleDTO ospedaleTrovato = ospedaleDAO.findByName(nomeRicercaOspedale);
	    if (ospedaleTrovato != null) {
	        System.out.println("Ospedale trovato: " + ospedaleTrovato.getNome());
	    } else {
	        System.out.println("Ospedale con nome '" + nomeRicercaOspedale + "' non trovato.");
	    }

	    
	    // Tipo Accertamento
	    TipoAccertamentoDAO tipoAccertamentoDAO = daoFactoryInstance.getTipoAccertamentoDAO();
	    tipoAccertamentoDAO.dropTable();
	    tipoAccertamentoDAO.createTable();

	    TipoAccertamentoDTO t1 = new TipoAccertamentoDTO();
	    t1.setCodiceTipoAccertamento("TA001");
	    t1.setDescrizione("Ecografia");
	    tipoAccertamentoDAO.create(t1);
	    System.out.println("Inserito tipoAccertamento con ID: " + t1.getId());

	    TipoAccertamentoDTO t2 = new TipoAccertamentoDTO();
	    t2.setCodiceTipoAccertamento("TA002");
	    t2.setDescrizione("Risonanza Magnetica");
	    tipoAccertamentoDAO.create(t2);
	    System.out.println("Inserito tipoAccertamento con ID: " + t2.getId());

	    TipoAccertamentoDTO t3 = new TipoAccertamentoDTO();
	    t3.setCodiceTipoAccertamento("TA003");
	    t3.setDescrizione("Analisi Laboratorio");
	    tipoAccertamentoDAO.create(t3);
	    System.out.println("Inserito tipoAccertamento con ID: " + t3.getId());
	    
	    
	    // Ricerca per TipoAccertamento (per codice)
	    String codiceRicercaTipoAccertamento = "TA002";  
	    TipoAccertamentoDTO tipoAccertamentoTrovato = tipoAccertamentoDAO.findByCodice(codiceRicercaTipoAccertamento);
	    if (tipoAccertamentoTrovato != null) {
	        System.out.println("Tipo Accertamento trovato: " + tipoAccertamentoTrovato.getDescrizione());
	    } else {
	        System.out.println("Tipo Accertamento con codice '" + codiceRicercaTipoAccertamento + "' non trovato.");
	    }

	    
	    // Mapping Ospedali TipiAccertamento
	    OspedaleTipoAccertamentoMappingDAO ota= new Db2OspedaliTipiAccertamentoMappingDAO();
	    ota.dropTable();
	    ota.createTable();
	    
	    // Ospedale 1 ha Ecografia e Analisi Laboratorio
	    System.out.println("Inserimento coppie per il mapping");
	    ota.create(o1.getId(), t1.getId());
	    ota.create(o1.getId(), t3.getId());
	    
	    // Ospedale 2 ha Risonanza
	    ota.create(o2.getId(), t2.getId());
	    
	    // Ospedale 3 ha Ecografia e Analisi Laboratorio
	    ota.create(o3.getId(), t1.getId());
	    ota.create(o3.getId(), t3.getId());


	    // Accertamenti
	    AccertamentoDAO accertamentoDAO = daoFactoryInstance.getAccertamentoDAO();
	    accertamentoDAO.dropTable();
	    accertamentoDAO.createTable();

	    AccertamentoDTO a1 = new AccertamentoDTO();
	    a1.setCodiceAccertamento("A001");
	    a1.setNome("Accertamento Ecografia");
	    a1.setDescrizione("Ecografia al torace");
	    a1.setIdTipoAccertamento(t1.getId()); // Associare accertamento con tipo ecografia
	    accertamentoDAO.create(a1);
	    System.out.println("Inserito accertamento con ID: " + a1.getId());

	    AccertamentoDTO a2 = new AccertamentoDTO();
	    a2.setCodiceAccertamento("A002");
	    a2.setNome("Accertamento RM");
	    a2.setDescrizione("Risonanza Magnetica alla testa");
	    a2.setIdTipoAccertamento(t2.getId()); // Associare accertamento con tipo risonanza
	    accertamentoDAO.create(a2);
	    System.out.println("Inserito accertamento con ID: " + a2.getId());

	    AccertamentoDTO a3 = new AccertamentoDTO();
	    a3.setCodiceAccertamento("A003");
	    a3.setNome("Accertamento Analisi");
	    a3.setDescrizione("Analisi del sangue");
	    a3.setIdTipoAccertamento(t3.getId()); // Associare accertamento con tipo Analisi Laboratorio
	    accertamentoDAO.create(a3);
	    System.out.println("Inserito accertamento con ID: " + a3.getId());

	    // Ricerca per Accertamento (per codice)
	    String codiceRicercaAccertamento = "A002"; 
	    AccertamentoDTO accertamentoTrovato = accertamentoDAO.findByCodice(codiceRicercaAccertamento);
	    if (accertamentoTrovato != null) {
	        System.out.println("Accertamento trovato: " + accertamentoTrovato.getDescrizione());
	    } else {
	        System.out.println("Accertamento con codice '" + codiceRicercaAccertamento + "' non trovato.");
	    }
	    
	    
	    // =============== QUERY =================================
	    
	    // Ricerca "Analisi Laboratorio" servite da "Ospedale Maggiore"
	    System.out.println("\n\nEsecuzione query: trovare tutti accertamenti di tipo Analisi Laboratorio offerti dal Sant'Orsola");
	    OspedaleDTO policlinico= ospedaleDAO.findByName("Policlinico Sant'Orsola-Malpighi");
	    List<TipoAccertamentoDTO> tipi= tipoAccertamentoDAO.findByDescrizioneAndOspedale("Analisi Laboratorio", policlinico.getId());
	    for(TipoAccertamentoDTO tipo: tipi) {
	    	for(AccertamentoDTO acc: tipo.getAccertamenti())
	    		System.out.println(acc.getCodiceAccertamento()+ " "+ acc.getDescrizione());
	    }
	    
	    // Ricerca su tutti gli ospedali, restituendo numero di accertamenti offerti
	    System.out.println("\n\nEsecuzione query: stampare per tutti gli ospedali, il numero di accertamenti offerti");
	    List<OspedaleDTO> ospedali= ospedaleDAO.readAll();
	    for(OspedaleDTO o : ospedali) {
	    	int nacc= 0;
	    	for(TipoAccertamentoDTO tipo : o.getTipiAccertamenti())
	    		nacc+= tipo.getAccertamenti().size();
	    	System.out.println("\n" + o.getNome()+ " - " + o.getCitta()+ " - "+ o.getIndirizzo()+ "\nNumero Accertamenti: " + nacc);
	    }
	}


}
