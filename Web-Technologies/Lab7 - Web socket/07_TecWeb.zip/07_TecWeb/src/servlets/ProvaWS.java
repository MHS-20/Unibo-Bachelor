package servlets;

import java.io.IOException;


import javax.servlet.http.HttpServlet;
import javax.websocket.*;
import javax.websocket.server.*;

import com.google.gson.Gson;

import beans.OperationReq;
import beans.OperationResp;
import java.util.*;


@ServerEndpoint("/actions")
public class ProvaWS{
	
	
	

}
